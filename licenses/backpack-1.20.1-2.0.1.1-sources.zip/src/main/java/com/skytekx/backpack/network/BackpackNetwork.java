package com.skytekx.backpack.network;

import com.skytekx.backpack.BackpackMod;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

/** The mod's network channel. The buttons of the workbench use the vanilla button packet instead. */
public final class BackpackNetwork {
    private static final String VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            BackpackMod.id("main"), () -> VERSION, VERSION::equals, VERSION::equals);

    private BackpackNetwork() {
    }

    public static void register() {
        CHANNEL.messageBuilder(RenameBackpackPacket.class, 0, NetworkDirection.PLAY_TO_SERVER)
                .encoder(RenameBackpackPacket::encode)
                .decoder(RenameBackpackPacket::decode)
                .consumerMainThread(RenameBackpackPacket::handle)
                .add();
    }
}
