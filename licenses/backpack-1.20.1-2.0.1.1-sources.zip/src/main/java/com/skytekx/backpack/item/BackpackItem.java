package com.skytekx.backpack.item;

import com.skytekx.backpack.client.ClientHooks;
import com.skytekx.backpack.menu.BackpackOpener;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.fml.DistExecutor;

/**
 * Every backpack item: normal, big, workbench and ender, undyed or in one of the 16 colors.
 *
 * <p>The item only carries a reference. Its contents live in the world under the UUID in
 * {@link #TAG_ID}, as they did in 2.0.1.
 */
public class BackpackItem extends Item {
    /** The UUID that names the saved contents. Assigned on the server when the backpack is opened first. */
    public static final String TAG_ID = "BackpackId";
    /** Set on workbench backpacks that went through the intelligent recipe. */
    public static final String TAG_INTELLIGENT = "Intelligent";
    /** The number of used storage slots, written by the server for the tooltip. */
    public static final String TAG_USED_SLOTS = "UsedSlots";

    private final BackpackKind kind;
    @Nullable
    private final DyeColor color;

    public BackpackItem(BackpackKind kind, @Nullable DyeColor color, Properties properties) {
        super(properties.stacksTo(1));
        this.kind = kind;
        this.color = color;
    }

    public BackpackKind kind() {
        return kind;
    }

    /** The color, or null for the undyed, workbench and ender backpacks. */
    @Nullable
    public DyeColor color() {
        return color;
    }

    @Override
    public boolean isBookEnchantable(ItemStack stack, ItemStack book) {
        return false;
    }

    /**
     * Right click opens the backpack on the server. Sneaking and right clicking opens the rename
     * screen on the client instead, except for the ender backpack, which cannot be renamed.
     *
     * <p>Fake players, such as the one of a Create deployer, get nothing. Their connection never
     * sends, so the packet of every menu they open would wait in its queue until the server stops.
     */
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player instanceof FakePlayer) {
            return InteractionResultHolder.pass(stack);
        }
        if (player.isShiftKeyDown()) {
            if (kind.isEnder()) {
                return InteractionResultHolder.pass(stack);
            }
            if (level.isClientSide) {
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openRenameScreen(hand));
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        if (player instanceof ServerPlayer serverPlayer) {
            BackpackOpener.open(serverPlayer, hand);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /**
     * The 2.0.1 tooltip. Without Shift it asks for Shift. With Shift it shows the tier and the
     * used slots, except on the ender backpack. Intelligent workbench backpacks always say so.
     */
    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        Boolean shift = DistExecutor.unsafeCallWhenOn(Dist.CLIENT, () -> ClientHooks::hasShiftDown);
        if (!Boolean.TRUE.equals(shift)) {
            tooltip.add(Component.translatable("tooltip.backpack.more_information").withStyle(ChatFormatting.GRAY));
        } else if (!kind.isEnder()) {
            tooltip.add(Component.translatable("tooltip.backpack.tier").append(" " + kind.tier()).withStyle(ChatFormatting.YELLOW));
            tooltip.add(Component.literal(getUsedSlots(stack) + "/" + kind.storageSize() + " ")
                    .append(Component.translatable("tooltip.backpack.slots_used")).withStyle(ChatFormatting.GRAY));
        }
        if (kind.isWorkbench() && isIntelligent(stack)) {
            tooltip.add(Component.translatable("tooltip.backpack.intelligent").withStyle(ChatFormatting.GRAY));
        }
    }

    @Nullable
    public static UUID getId(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.hasUUID(TAG_ID) ? tag.getUUID(TAG_ID) : null;
    }

    /** Returns the UUID of the backpack and assigns a new one first if it has none. */
    public static UUID getOrCreateId(ItemStack stack) {
        UUID id = getId(stack);
        if (id == null) {
            id = UUID.randomUUID();
            stack.getOrCreateTag().putUUID(TAG_ID, id);
        }
        return id;
    }

    public static boolean isIntelligent(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.getBoolean(TAG_INTELLIGENT);
    }

    public static int getUsedSlots(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null ? tag.getInt(TAG_USED_SLOTS) : 0;
    }

    public static void setUsedSlots(ItemStack stack, int usedSlots) {
        if (getUsedSlots(stack) != usedSlots || !stack.hasTag() || !stack.getTag().contains(TAG_USED_SLOTS)) {
            stack.getOrCreateTag().putInt(TAG_USED_SLOTS, usedSlots);
        }
    }
}
