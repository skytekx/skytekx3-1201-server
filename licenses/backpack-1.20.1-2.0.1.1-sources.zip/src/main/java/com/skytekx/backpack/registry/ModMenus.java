package com.skytekx.backpack.registry;

import com.skytekx.backpack.BackpackMod;
import com.skytekx.backpack.menu.BackpackMenu;
import com.skytekx.backpack.menu.WorkbenchBackpackMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, BackpackMod.MOD_ID);

    public static final RegistryObject<MenuType<BackpackMenu>> BACKPACK =
            MENUS.register("backpack", () -> IForgeMenuType.create(BackpackMenu::fromNetwork));
    public static final RegistryObject<MenuType<WorkbenchBackpackMenu>> WORKBENCH_BACKPACK =
            MENUS.register("workbench_backpack", () -> IForgeMenuType.create(WorkbenchBackpackMenu::fromNetwork));

    private ModMenus() {
    }
}
