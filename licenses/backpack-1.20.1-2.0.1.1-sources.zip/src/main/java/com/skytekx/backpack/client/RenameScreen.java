package com.skytekx.backpack.client;

import com.skytekx.backpack.network.BackpackNetwork;
import com.skytekx.backpack.network.RenameBackpackPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import org.lwjgl.glfw.GLFW;

/** The rename screen of 2.0.1, opened by sneaking and right clicking with a backpack. */
public class RenameScreen extends Screen {
    private static final int WIDTH = 240;
    private static final int HEIGHT = 100;
    private static final Component LABEL = Component.translatable("text.backpack.new_name");

    private final InteractionHand hand;
    private EditBox nameField;
    private Button okButton;
    private int left;
    private int top;

    public RenameScreen(InteractionHand hand) {
        super(Component.translatable("text.backpack.rename"));
        this.hand = hand;
    }

    @Override
    protected void init() {
        left = (width - WIDTH) / 2;
        top = (height - HEIGHT) / 2;
        String previous = nameField != null ? nameField.getValue() : "";
        nameField = new EditBox(font, left + 20, top + 40, 200, 20, LABEL);
        nameField.setMaxLength(RenameBackpackPacket.MAX_LENGTH);
        nameField.setValue(previous);
        nameField.setResponder(text -> updateOkButton());
        addRenderableWidget(nameField);
        addRenderableWidget(Button.builder(Component.translatable("button.backpack.cancel"), button -> onClose())
                .bounds(left + 40, top + 70, 60, 20).build());
        okButton = addRenderableWidget(Button.builder(Component.translatable("button.backpack.ok"), button -> confirm())
                .bounds(left + 140, top + 70, 60, 20).build());
        setInitialFocus(nameField);
        updateOkButton();
    }

    private void updateOkButton() {
        okButton.active = RenameBackpackPacket.validName(nameField.getValue()) != null;
    }

    private void confirm() {
        String name = RenameBackpackPacket.validName(nameField.getValue());
        if (name != null) {
            BackpackNetwork.CHANNEL.sendToServer(new RenameBackpackPacket(hand, name));
        }
        onClose();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            if (okButton.active) {
                confirm();
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void tick() {
        nameField.tick();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        GuiParts.window(graphics, left, top, WIDTH, HEIGHT);
        graphics.drawString(font, title, left + (WIDTH - font.width(title)) / 2, top + 10, 0x000000, false);
        graphics.drawString(font, LABEL, left + 20, top + 30, GuiParts.LABEL_COLOR, false);
        super.render(graphics, mouseX, mouseY, partialTick);
    }
}
