package com.skytekx.backpack.client;

import com.skytekx.backpack.BackpackMod;
import com.skytekx.backpack.registry.ModMenus;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/** Client setup. Forge only loads this class on the physical client. */
@Mod.EventBusSubscriber(modid = BackpackMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientSetup {
    private ClientSetup() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            MenuScreens.register(ModMenus.BACKPACK.get(), BackpackScreen::new);
            MenuScreens.register(ModMenus.WORKBENCH_BACKPACK.get(), WorkbenchBackpackScreen::new);
        });
    }
}
