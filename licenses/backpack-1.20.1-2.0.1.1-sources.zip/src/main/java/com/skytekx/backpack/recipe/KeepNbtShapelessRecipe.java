package com.skytekx.backpack.recipe;

import com.google.gson.JsonObject;
import com.skytekx.backpack.registry.ModRecipes;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.ShapelessRecipe;

/**
 * A vanilla shapeless recipe whose result keeps the NBT of the backpack in the grid. It covers
 * recoloring, undyeing and the intelligent workbench backpack of 2.0.1.
 */
public class KeepNbtShapelessRecipe extends ShapelessRecipe {
    public KeepNbtShapelessRecipe(ShapelessRecipe base) {
        super(base.getId(), base.getGroup(), base.category(), base.getResultItem(RegistryAccess.EMPTY), base.getIngredients());
    }

    @Override
    public ItemStack assemble(CraftingContainer container, RegistryAccess registryAccess) {
        return KeepNbt.apply(container, super.assemble(container, registryAccess));
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return ModRecipes.KEEP_NBT_SHAPELESS.get();
    }

    /** Reads and writes the vanilla shapeless format. */
    public static class Serializer implements RecipeSerializer<KeepNbtShapelessRecipe> {
        @Override
        public KeepNbtShapelessRecipe fromJson(ResourceLocation id, JsonObject json) {
            return new KeepNbtShapelessRecipe(RecipeSerializer.SHAPELESS_RECIPE.fromJson(id, json));
        }

        @Override
        public KeepNbtShapelessRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buffer) {
            return new KeepNbtShapelessRecipe(RecipeSerializer.SHAPELESS_RECIPE.fromNetwork(id, buffer));
        }

        @Override
        public void toNetwork(FriendlyByteBuf buffer, KeepNbtShapelessRecipe recipe) {
            RecipeSerializer.SHAPELESS_RECIPE.toNetwork(buffer, recipe);
        }
    }
}
