package com.skytekx.backpack.menu;

import com.skytekx.backpack.item.BackpackKind;
import javax.annotation.Nullable;
import net.minecraft.network.FriendlyByteBuf;

/**
 * What the client needs to build a backpack menu: the kind, the inventory slot of the held
 * backpack and whether a workbench backpack is intelligent.
 */
public record MenuInfo(BackpackKind kind, int lockedSlot, boolean intelligent) {
    public void write(FriendlyByteBuf buffer) {
        buffer.writeByte(kind.ordinal());
        buffer.writeVarInt(lockedSlot);
        buffer.writeBoolean(intelligent);
    }

    public static MenuInfo read(@Nullable FriendlyByteBuf buffer, BackpackKind fallback) {
        if (buffer == null) {
            return new MenuInfo(fallback, -1, false);
        }
        return new MenuInfo(BackpackKind.byOrdinal(buffer.readByte()), buffer.readVarInt(), buffer.readBoolean());
    }
}
