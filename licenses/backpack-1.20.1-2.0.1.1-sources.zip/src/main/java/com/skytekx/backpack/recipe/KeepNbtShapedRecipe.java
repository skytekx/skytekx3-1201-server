package com.skytekx.backpack.recipe;

import com.google.gson.JsonObject;
import com.skytekx.backpack.registry.ModRecipes;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.ShapedRecipe;

/**
 * A vanilla shaped recipe whose result keeps the NBT of the backpack in the grid. It is the
 * upgrade to a big backpack of 2.0.1 ({@code RecipeEnhanceBackpack}), so the UUID and with it
 * the contents and the custom name survive.
 */
public class KeepNbtShapedRecipe extends ShapedRecipe {
    public KeepNbtShapedRecipe(ShapedRecipe base) {
        super(base.getId(), base.getGroup(), base.category(), base.getWidth(), base.getHeight(),
                base.getIngredients(), base.getResultItem(RegistryAccess.EMPTY), base.showNotification());
    }

    @Override
    public ItemStack assemble(CraftingContainer container, RegistryAccess registryAccess) {
        return KeepNbt.apply(container, super.assemble(container, registryAccess));
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return ModRecipes.KEEP_NBT_SHAPED.get();
    }

    /** Reads and writes the vanilla shaped format. */
    public static class Serializer implements RecipeSerializer<KeepNbtShapedRecipe> {
        @Override
        public KeepNbtShapedRecipe fromJson(ResourceLocation id, JsonObject json) {
            return new KeepNbtShapedRecipe(RecipeSerializer.SHAPED_RECIPE.fromJson(id, json));
        }

        @Override
        public KeepNbtShapedRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buffer) {
            return new KeepNbtShapedRecipe(RecipeSerializer.SHAPED_RECIPE.fromNetwork(id, buffer));
        }

        @Override
        public void toNetwork(FriendlyByteBuf buffer, KeepNbtShapedRecipe recipe) {
            RecipeSerializer.SHAPED_RECIPE.toNetwork(buffer, recipe);
        }
    }
}
