package com.skytekx.backpack.registry;

import com.skytekx.backpack.BackpackMod;
import com.skytekx.backpack.recipe.KeepNbtShapedRecipe;
import com.skytekx.backpack.recipe.KeepNbtShapelessRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRecipes {
    public static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS = DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, BackpackMod.MOD_ID);

    public static final RegistryObject<KeepNbtShapedRecipe.Serializer> KEEP_NBT_SHAPED =
            SERIALIZERS.register("crafting_shaped_keep_nbt", KeepNbtShapedRecipe.Serializer::new);
    public static final RegistryObject<KeepNbtShapelessRecipe.Serializer> KEEP_NBT_SHAPELESS =
            SERIALIZERS.register("crafting_shapeless_keep_nbt", KeepNbtShapelessRecipe.Serializer::new);

    private ModRecipes() {
    }
}
