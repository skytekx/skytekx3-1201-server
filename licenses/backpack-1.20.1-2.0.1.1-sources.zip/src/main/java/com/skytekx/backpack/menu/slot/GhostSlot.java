package com.skytekx.backpack.menu.slot;

import net.minecraft.world.Container;

/**
 * A slot of the ghost crafting grid. It shows a copy of an item and never holds a real one. The
 * menu sets and clears it on clicks, see {@code WorkbenchBackpackMenu}.
 */
public class GhostSlot extends DisplaySlot {
    public GhostSlot(EmptyContainer placeholder, Container ghosts, int index, int x, int y) {
        super(placeholder, ghosts, index, x, y);
    }

    @Override
    public int getMaxStackSize() {
        return 1;
    }
}
