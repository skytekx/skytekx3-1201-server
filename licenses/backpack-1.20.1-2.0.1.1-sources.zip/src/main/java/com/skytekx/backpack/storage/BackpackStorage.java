package com.skytekx.backpack.storage;

import com.skytekx.backpack.BackpackMod;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.DimensionDataStorage;
import net.minecraft.world.level.storage.LevelResource;

/** Finds the saved contents of a backpack on the server. */
public final class BackpackStorage {
    private BackpackStorage() {
    }

    public static String fileName(UUID id) {
        return "backpack_" + id;
    }

    /** Returns the live contents of the backpack with the given UUID and creates them if missing. */
    public static BackpackData get(MinecraftServer server, UUID id) {
        DimensionDataStorage storage = server.overworld().getDataStorage();
        String name = fileName(id);
        BackpackData data = storage.get(BackpackData::load, name);
        if (data != null) {
            return data;
        }
        keepUnreadableFile(server, name);
        return storage.computeIfAbsent(BackpackData::load, BackpackData::new, name);
    }

    /**
     * Vanilla replaces a data file it cannot read with a new one on the next save. A copy of
     * such a file is kept next to it, so the contents can still be recovered by hand.
     */
    private static void keepUnreadableFile(MinecraftServer server, String name) {
        Path file = server.getWorldPath(LevelResource.ROOT).resolve("data").resolve(name + ".dat");
        if (Files.isRegularFile(file)) {
            Path copy = file.resolveSibling(name + ".dat.unreadable-" + System.currentTimeMillis());
            try {
                Files.copy(file, copy, StandardCopyOption.COPY_ATTRIBUTES);
                BackpackMod.LOGGER.error("Could not read backpack data {}, kept a copy as {}", file, copy.getFileName());
            } catch (IOException e) {
                BackpackMod.LOGGER.error("Could not read backpack data {} and could not copy it", file, e);
            }
        }
    }
}
