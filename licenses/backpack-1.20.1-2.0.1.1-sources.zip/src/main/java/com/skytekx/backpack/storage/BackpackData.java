package com.skytekx.backpack.storage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * The saved contents of one backpack, stored as {@code data/backpack_<uuid>.dat} in the
 * overworld folder of the world. It replaces the 2.0.1 file {@code backpacks/backpacks/<uuid>.dat}.
 *
 * <p>The server keeps one live instance per UUID, so every open menu of the same backpack edits
 * the same stacks. Files are never deleted.
 */
public class BackpackData extends SavedData {
    public static final int GRID_SIZE = 9;
    public static final int RECIPE_COUNT = 9;

    private static final String TAG_SIZE = "Size";
    private static final String TAG_ITEMS = "Items";
    private static final String TAG_GRID = "Grid";
    private static final String TAG_RECIPE_ICONS = "RecipeIcons";
    private static final String TAG_RECIPE_GRIDS = "RecipeGrids";
    private static final String TAG_SLOT = "Slot";

    private final ListContainer storage = new ListContainer(0, 64, BackpackRules::mayStore, this::setDirty);
    private final ListContainer grid = new ListContainer(GRID_SIZE, 1, stack -> true, this::gridChanged);
    private final ListContainer recipeIcons = new ListContainer(RECIPE_COUNT, 64, stack -> true, this::setDirty);
    private final List<NonNullList<ItemStack>> recipeGrids;
    private int gridVersion;

    public BackpackData() {
        List<NonNullList<ItemStack>> grids = new ArrayList<>();
        for (int i = 0; i < RECIPE_COUNT; i++) {
            grids.add(NonNullList.withSize(GRID_SIZE, ItemStack.EMPTY));
        }
        recipeGrids = Collections.unmodifiableList(grids);
    }

    /** The storage slots. It holds at least as many slots as the backpack kind needs once opened. */
    public ListContainer storage() {
        return storage;
    }

    /** The 3 by 3 ghost grid of workbench backpacks. */
    public ListContainer grid() {
        return grid;
    }

    /** The icons of the 9 saved recipes of intelligent workbench backpacks. */
    public ListContainer recipeIcons() {
        return recipeIcons;
    }

    /** Counts up on every change of the ghost grid, so open menus know when to update the result. */
    public int gridVersion() {
        return gridVersion;
    }

    /** Stores the current ghost grid and its result under the given recipe slot. */
    public void saveRecipe(int index, ItemStack icon) {
        NonNullList<ItemStack> target = recipeGrids.get(index);
        for (int i = 0; i < GRID_SIZE; i++) {
            target.set(i, grid.getItem(i).copy());
        }
        recipeIcons.setItem(index, icon.copy());
    }

    /** Replaces the ghost grid with the ingredients saved under the given recipe slot. */
    public void loadRecipe(int index) {
        NonNullList<ItemStack> source = recipeGrids.get(index);
        for (int i = 0; i < GRID_SIZE; i++) {
            grid.items().set(i, source.get(i).copy());
        }
        grid.setChanged();
    }

    public void clearGrid() {
        grid.clearContent();
    }

    private void gridChanged() {
        gridVersion++;
        setDirty();
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putInt(TAG_SIZE, storage.getContainerSize());
        tag.put(TAG_ITEMS, writeStacks(storage.items()));
        tag.put(TAG_GRID, writeStacks(grid.items()));
        tag.put(TAG_RECIPE_ICONS, writeStacks(recipeIcons.items()));
        ListTag grids = new ListTag();
        for (int i = 0; i < RECIPE_COUNT; i++) {
            ListTag stacks = writeStacks(recipeGrids.get(i));
            if (!stacks.isEmpty()) {
                CompoundTag entry = new CompoundTag();
                entry.putByte(TAG_SLOT, (byte) i);
                entry.put(TAG_ITEMS, stacks);
                grids.add(entry);
            }
        }
        tag.put(TAG_RECIPE_GRIDS, grids);
        return tag;
    }

    public static BackpackData load(CompoundTag tag) {
        BackpackData data = new BackpackData();
        ListTag items = tag.getList(TAG_ITEMS, Tag.TAG_COMPOUND);
        int size = tag.getInt(TAG_SIZE);
        for (int i = 0; i < items.size(); i++) {
            size = Math.max(size, (items.getCompound(i).getByte(TAG_SLOT) & 255) + 1);
        }
        data.storage.ensureSize(size);
        readStacks(items, data.storage.items());
        readStacks(tag.getList(TAG_GRID, Tag.TAG_COMPOUND), data.grid.items());
        readStacks(tag.getList(TAG_RECIPE_ICONS, Tag.TAG_COMPOUND), data.recipeIcons.items());
        ListTag grids = tag.getList(TAG_RECIPE_GRIDS, Tag.TAG_COMPOUND);
        for (int i = 0; i < grids.size(); i++) {
            CompoundTag entry = grids.getCompound(i);
            int index = entry.getByte(TAG_SLOT) & 255;
            if (index < RECIPE_COUNT) {
                readStacks(entry.getList(TAG_ITEMS, Tag.TAG_COMPOUND), data.recipeGrids.get(index));
            }
        }
        data.setDirty(false);
        return data;
    }

    private static ListTag writeStacks(List<ItemStack> stacks) {
        ListTag list = new ListTag();
        for (int i = 0; i < stacks.size(); i++) {
            ItemStack stack = stacks.get(i);
            if (!stack.isEmpty()) {
                CompoundTag entry = new CompoundTag();
                entry.putByte(TAG_SLOT, (byte) i);
                stack.save(entry);
                list.add(entry);
            }
        }
        return list;
    }

    private static void readStacks(ListTag list, List<ItemStack> target) {
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            int slot = entry.getByte(TAG_SLOT) & 255;
            if (slot < target.size()) {
                target.set(slot, ItemStack.of(entry));
            }
        }
    }
}
