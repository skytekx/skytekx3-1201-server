package com.skytekx.backpack.registry;

import com.skytekx.backpack.BackpackMod;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;

public final class ModTags {
    /** All 37 backpacks. */
    public static final TagKey<Item> BACKPACKS = ItemTags.create(BackpackMod.id("backpacks"));
    /** The undyed backpack and its 16 colors. */
    public static final TagKey<Item> SMALL_BACKPACKS = ItemTags.create(BackpackMod.id("small_backpacks"));
    /** The undyed big backpack and its 16 colors. */
    public static final TagKey<Item> BIG_BACKPACKS = ItemTags.create(BackpackMod.id("big_backpacks"));
    /**
     * Items that backpack storage refuses. It holds all backpacks by default and replaces the
     * disallowItems setting of 2.0.1. Backpacks are refused even when a data pack removes them.
     */
    public static final TagKey<Item> NOT_ALLOWED_IN_BACKPACKS = ItemTags.create(BackpackMod.id("not_allowed_in_backpacks"));

    private ModTags() {
    }
}
