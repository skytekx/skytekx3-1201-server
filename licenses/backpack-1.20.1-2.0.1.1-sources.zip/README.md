# Backpack for Forge 1.20.1

This is an unofficial port of Backpack 2.0.1 by Eydamos from Minecraft 1.7.10 to Minecraft 1.20.1 with Forge 47 and Java 17. It was made for the SkyTekx3 modpack and keeps the mod id `backpack`. It is neither affiliated with nor endorsed by Eydamos. Bug reports about this port belong here and not to the original author.

## Credits

- Eydamos wrote Backpack and its GUI library.
- MightyPork made the backpacks up to Minecraft 1.2.5.
- Simsala123 and SentientXIII drew the icons.
- Ivanovsky made the backpack model.

The item textures, the GUI texture sheet and the English and German texts are the originals from 2.0.1.

## License

The original mod is licensed under the LGPL 2.1 according to its CurseForge page, and so is this port. The full text is in [LICENSE](LICENSE) and ships inside the jar as `LICENSE_backpack`.

Backpack 2.0.1 is copyright Eydamos and contributors. The port to Minecraft 1.20.1 was made by kleberbaum in 2026. The file [NOTICE](NOTICE) says what the port changed and ships inside the jar as `NOTICE_backpack`. This port is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the LGPL 2.1 for more details.

Whoever gives the mod jar to others, for example in a modpack, has to give them the sources zip from the build as well or offer the source from a public place, as section 4 of the LGPL asks.

## Items

| Item | Storage |
|---|---|
| Backpack and its 16 colors | 27 slots |
| Big backpack and its 16 colors | 54 slots |
| Workbench backpack | 9 slots, a ghost crafting grid and a result slot |
| Big workbench backpack | 18 slots, a ghost crafting grid and a result slot |
| Ender backpack | The player's own ender chest |
| Bound leather and tanned leather | Crafting materials |

## How it works

- Right click opens a backpack. Sneaking and right clicking opens the rename screen, which takes 1 to 32 characters. The ender backpack cannot be renamed.
- The recipes are the ones of 2.0.1. Leather, string, dyes and the ender chest are matched through their Forge tags, so modded variants work. Bound leather smelts into tanned leather.
- Tanned leather around a normal backpack or the small workbench backpack upgrades it to the big one. A backpack and a dye change its color, leather or tanned leather removes it again, and a book and quill makes a workbench backpack intelligent. These recipes keep the contents, the custom name and the intelligent flag.
- The item only holds a UUID. The contents live in the world as `data/backpack_<uuid>.dat` in the overworld folder. Files are never deleted.
- While a backpack is open, its inventory slot is locked, so it cannot be moved, thrown or swapped away. The menu closes when the slot no longer holds that backpack.
- Storage refuses backpacks and every item in the tag `backpack:not_allowed_in_backpacks`, which a data pack can extend.
- Workbench backpacks show the result of the ghost grid and craft it from their own storage only. A stack that the recipe accepts in place of the ghost item counts too, so oak planks in the grid also take spruce planks. Container items such as empty buckets go back into the storage. One shift click crafts up to 64 times while the ingredients and the space last. The button c or the key c clears the grid.
- Intelligent workbench backpacks remember nine recipes. The button s or the key s starts save mode, and the next click on a recipe slot stores the current grid there. Outside save mode a click on a recipe slot loads it.
- With Shift held, the tooltip shows the tier and the number of used slots.
- Inventory Sorter leaves the ghost grid, the recipe slots, the result slot and the locked slot alone.

## Changes against 2.0.1

- Two menus of the same backpack now share one live inventory. In 2.0.1 the last one to close overwrote the other, which could duplicate or delete items.
- The open backpack is locked in its slot as in Backpack 3.0.2. In 2.0.1 moving it closed the menu and dropped it on the ground.
- Shift click crafting in a workbench backpack no longer loses the part of the stack that does not fit.
- One shift click on the workbench result crafts at most 64 times, as many as a full vanilla crafting grid allows. In 2.0.1 it went on until the ingredients or the space ran out. The limit keeps a recipe whose output is also its input from looping forever on the server.
- The tooltip shows the real slot count and the intelligent flag. In 2.0.1 it always showed 0/0.
- The custom name is the vanilla item name, shown without italics.

## Left out

- The personal backpack slot, its key binding (B by default), the automatic pickup filter and the backpack model on the player.
- The settings that belong to them, `maxBackpackAmount` and `openOnlyWornBackpacks`.
- The configuration file. Data packs or KubeJS can change the recipes, and the tag above replaces `disallowItems`. Slot counts are fixed at the defaults of 2.0.1.
- The recipe variants for airships and for the eye of ender.
- The version check, the support for NEI and Inventory Tweaks and the in game configuration screen.
- The medium tier, which never worked in 2.0.1.
- Recipe transfer from EMI or JEI into the ghost grid.
- Migration of 1.7.10 worlds. Their save files store numeric item ids, so backpacks start empty.

## Building and testing

The build needs a JDK 17.

- Run `./gradlew build` to write the mod to `build/libs/backpack-1.20.1-2.0.1.1.jar` and its complete source, with the scripts that build it, to `build/libs/backpack-1.20.1-2.0.1.1-sources.zip`.
- Run `./gradlew runGameTestServer` to run the GameTests in `src/gametest` on a Forge game test server. It exits with the number of failed tests.
- Run `./gradlew runServer` to start a dedicated development server in `run/server`.

The file [docs/original-2.0.1.md](docs/original-2.0.1.md) describes the original mod in detail and was the reference for this port.
