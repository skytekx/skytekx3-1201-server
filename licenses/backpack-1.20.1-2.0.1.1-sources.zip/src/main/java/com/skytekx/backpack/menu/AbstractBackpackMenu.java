package com.skytekx.backpack.menu;

import com.skytekx.backpack.item.BackpackItem;
import com.skytekx.backpack.item.BackpackKind;
import com.skytekx.backpack.menu.slot.LockedSlot;
import com.skytekx.backpack.menu.slot.StorageSlot;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.NonNullList;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/**
 * The parts every backpack menu shares: the storage slots, the player inventory with the locked
 * slot of the held backpack, shift click and the check that the backpack is still held.
 */
public abstract class AbstractBackpackMenu extends AbstractContainerMenu {
    public static final int OFFHAND_SLOT = Inventory.SLOT_OFFHAND;

    protected final Inventory playerInventory;
    protected final Player player;
    protected final BackpackKind kind;
    protected final Container storage;
    /** The inventory slot of the held backpack, 0 to 8 for the hotbar or 40 for the offhand. */
    protected final int lockedSlot;
    /** The UUID of the open backpack on the server, null on the client and for the ender backpack. */
    @Nullable
    protected final UUID backpackId;
    /** Marks the saved data dirty on the server, null on the client and for the ender backpack. */
    @Nullable
    private final Runnable onStorageChanged;
    private final NonNullList<ItemStack> lastStorage;
    private int lastUsedSlots = -1;

    protected int storageStart;
    protected int storageEnd;
    protected int inventoryStart;
    protected int inventoryEnd;
    protected int hotbarStart;
    protected int hotbarEnd;

    protected AbstractBackpackMenu(MenuType<?> type, int containerId, Inventory playerInventory, Container storage,
                                   BackpackKind kind, int lockedSlot, @Nullable UUID backpackId, @Nullable Runnable onStorageChanged) {
        super(type, containerId);
        this.playerInventory = playerInventory;
        this.player = playerInventory.player;
        this.kind = kind;
        this.storage = storage;
        this.lockedSlot = lockedSlot;
        this.backpackId = backpackId;
        this.onStorageChanged = onStorageChanged;
        this.lastStorage = NonNullList.withSize(kind.storageSize(), ItemStack.EMPTY);
        for (int i = 0; i < lastStorage.size(); i++) {
            lastStorage.set(i, storage.getItem(i).copy());
        }
        storage.startOpen(player);
    }

    public BackpackKind kind() {
        return kind;
    }

    public int lockedSlot() {
        return lockedSlot;
    }

    /** The menu index of the first storage slot. */
    public int storageStart() {
        return storageStart;
    }

    /** The menu index of the first main inventory slot, player inventory slot 9. */
    public int inventoryStart() {
        return inventoryStart;
    }

    /** The menu index of the first hotbar slot, player inventory slot 0. */
    public int hotbarStart() {
        return hotbarStart;
    }

    protected void addStorageSlots(int left, int top) {
        storageStart = slots.size();
        for (int i = 0; i < kind.storageSize(); i++) {
            addSlot(new StorageSlot(storage, i, left + 18 * (i % 9), top + 18 * (i / 9)));
        }
        storageEnd = slots.size();
    }

    protected void addPlayerSlots(int inventoryTop, int hotbarTop) {
        inventoryStart = slots.size();
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                addSlot(playerSlot(9 + row * 9 + column, 8 + 18 * column, inventoryTop + 18 * row));
            }
        }
        inventoryEnd = slots.size();
        hotbarStart = slots.size();
        for (int column = 0; column < 9; column++) {
            addSlot(playerSlot(column, 8 + 18 * column, hotbarTop));
        }
        hotbarEnd = slots.size();
    }

    private Slot playerSlot(int index, int x, int y) {
        return index == lockedSlot ? new LockedSlot(playerInventory, index, x, y) : new Slot(playerInventory, index, x, y);
    }

    protected boolean isStorageSlot(int index) {
        return index >= storageStart && index < storageEnd;
    }

    @Override
    public void clicked(int slotId, int button, ClickType clickType, Player player) {
        // A number key or the offhand key would move the held backpack out of its slot.
        if (clickType == ClickType.SWAP && button == lockedSlot) {
            return;
        }
        if (slotId >= 0 && slotId < slots.size() && slots.get(slotId) instanceof LockedSlot) {
            return;
        }
        super.clicked(slotId, button, clickType, player);
    }

    @Override
    public boolean stillValid(Player player) {
        if (player.level().isClientSide) {
            return true;
        }
        if (!player.isAlive()) {
            return false;
        }
        if (kind.isEnder()) {
            return true;
        }
        ItemStack held = player.getInventory().getItem(lockedSlot);
        return held.getItem() instanceof BackpackItem item && item.kind() == kind
                && backpackId != null && backpackId.equals(BackpackItem.getId(held));
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = slots.get(index);
        if (!slot.hasItem() || !slot.mayPickup(player)) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        boolean moved;
        if (isStorageSlot(index)) {
            moved = moveItemStackTo(stack, hotbarStart, hotbarEnd, true);
            moved |= moveItemStackTo(stack, inventoryStart, inventoryEnd, false);
        } else if (index >= inventoryStart && index < inventoryEnd) {
            moved = moveItemStackTo(stack, storageStart, storageEnd, false);
            moved |= moveItemStackTo(stack, hotbarStart, hotbarEnd, true);
        } else if (index >= hotbarStart && index < hotbarEnd) {
            moved = moveItemStackTo(stack, storageStart, storageEnd, false);
            moved |= moveItemStackTo(stack, inventoryStart, inventoryEnd, false);
        } else {
            return ItemStack.EMPTY;
        }
        if (!moved) {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        if (stack.getCount() == original.getCount()) {
            return ItemStack.EMPTY;
        }
        slot.onTake(player, stack);
        return original;
    }

    /**
     * The vanilla merge with one change: it also asks {@link Slot#mayPlace} before it tops up an
     * existing stack, so a refused item never grows a stack that got in some other way.
     */
    @Override
    protected boolean moveItemStackTo(ItemStack stack, int start, int end, boolean reverse) {
        boolean moved = false;
        if (stack.isStackable()) {
            int i = reverse ? end - 1 : start;
            while (!stack.isEmpty() && (reverse ? i >= start : i < end)) {
                Slot slot = slots.get(i);
                ItemStack existing = slot.getItem();
                if (!existing.isEmpty() && ItemStack.isSameItemSameTags(stack, existing) && slot.mayPlace(stack)) {
                    int max = Math.min(slot.getMaxStackSize(), stack.getMaxStackSize());
                    int total = existing.getCount() + stack.getCount();
                    if (total <= max) {
                        stack.setCount(0);
                        existing.setCount(total);
                        slot.setChanged();
                        moved = true;
                    } else if (existing.getCount() < max) {
                        stack.shrink(max - existing.getCount());
                        existing.setCount(max);
                        slot.setChanged();
                        moved = true;
                    }
                }
                i += reverse ? -1 : 1;
            }
        }
        if (!stack.isEmpty()) {
            int i = reverse ? end - 1 : start;
            while (reverse ? i >= start : i < end) {
                Slot slot = slots.get(i);
                if (!slot.hasItem() && slot.mayPlace(stack)) {
                    slot.setByPlayer(stack.split(Math.min(stack.getCount(), slot.getMaxStackSize(stack))));
                    slot.setChanged();
                    moved = true;
                    break;
                }
                i += reverse ? -1 : 1;
            }
        }
        return moved;
    }

    /** Counts how many of the given stack the slots in the range can still take. */
    protected int roomFor(ItemStack stack, int start, int end) {
        int room = 0;
        for (int i = start; i < end; i++) {
            Slot slot = slots.get(i);
            if (!slot.mayPlace(stack)) {
                continue;
            }
            ItemStack existing = slot.getItem();
            int max = Math.min(slot.getMaxStackSize(stack), stack.getMaxStackSize());
            if (existing.isEmpty()) {
                room += max;
            } else if (ItemStack.isSameItemSameTags(stack, existing)) {
                room += Math.max(0, max - existing.getCount());
            }
        }
        return room;
    }

    @Override
    public void broadcastChanges() {
        if (onStorageChanged != null) {
            trackStorage();
        }
        super.broadcastChanges();
    }

    /**
     * Marks the saved data dirty when a storage stack changed in any way, also when other code
     * changed a stack without telling the container, and keeps the slot count on the held item
     * up to date for the tooltip.
     */
    private void trackStorage() {
        boolean changed = false;
        int used = 0;
        for (int i = 0; i < lastStorage.size(); i++) {
            ItemStack current = storage.getItem(i);
            if (!current.isEmpty()) {
                used++;
            }
            if (!ItemStack.matches(current, lastStorage.get(i))) {
                lastStorage.set(i, current.copy());
                changed = true;
            }
        }
        if (changed) {
            onStorageChanged.run();
        }
        if (used != lastUsedSlots) {
            lastUsedSlots = used;
            ItemStack held = playerInventory.getItem(lockedSlot);
            if (held.getItem() instanceof BackpackItem && backpackId != null && backpackId.equals(BackpackItem.getId(held))) {
                BackpackItem.setUsedSlots(held, used);
            }
        }
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        storage.stopOpen(player);
        if (onStorageChanged != null) {
            trackStorage();
            onStorageChanged.run();
        }
    }
}
