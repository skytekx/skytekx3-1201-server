package com.skytekx.backpack.gametest;

import com.mojang.authlib.GameProfile;
import com.skytekx.backpack.BackpackMod;
import com.skytekx.backpack.item.BackpackItem;
import com.skytekx.backpack.menu.AbstractBackpackMenu;
import com.skytekx.backpack.menu.BackpackMenu;
import com.skytekx.backpack.menu.BackpackOpener;
import com.skytekx.backpack.menu.WorkbenchBackpackMenu;
import com.skytekx.backpack.network.RenameBackpackPacket;
import com.skytekx.backpack.recipe.KeepNbtShapedRecipe;
import com.skytekx.backpack.recipe.KeepNbtShapelessRecipe;
import com.skytekx.backpack.registry.ModItems;
import com.skytekx.backpack.storage.BackpackData;
import com.skytekx.backpack.storage.BackpackStorage;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.NonNullList;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestAssertException;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.wrapper.InvWrapper;

/**
 * Server side tests of the port. They run on the Forge game test server with
 * {@code ./gradlew runGameTestServer}, which exits with the number of failed tests.
 */
@GameTestHolder(BackpackMod.MOD_ID)
@PrefixGameTestTemplate(false)
public final class BackpackGameTests {
    private static final String EMPTY = "empty";

    private BackpackGameTests() {
    }

    // Helpers

    private static void check(boolean condition, String message) {
        if (!condition) {
            throw new GameTestAssertException(message);
        }
    }

    private static FakePlayer player(GameTestHelper helper) {
        UUID id = UUID.randomUUID();
        FakePlayer player = FakePlayerFactory.get(helper.getLevel(), new GameProfile(id, "bp" + id.toString().substring(0, 8)));
        Vec3 position = helper.absoluteVec(new Vec3(1.5, 1, 1.5));
        player.setPos(position.x, position.y, position.z);
        player.getInventory().clearContent();
        player.getEnderChestInventory().clearContent();
        player.getInventory().selected = 0;
        player.setShiftKeyDown(false);
        return player;
    }

    /**
     * A server player that is not a fake player. It is never added to the world, and the packets
     * it is sent wait in a connection without a channel until the test drops the player.
     */
    private static ServerPlayer plainPlayer(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        UUID id = UUID.randomUUID();
        ServerPlayer player = new ServerPlayer(level.getServer(), level, new GameProfile(id, "bp" + id.toString().substring(0, 8)));
        player.connection = new ServerGamePacketListenerImpl(level.getServer(), new Connection(PacketFlow.SERVERBOUND), player);
        player.getInventory().selected = 0;
        return player;
    }

    private static AbstractBackpackMenu open(FakePlayer player, InteractionHand hand) {
        BackpackOpener.open(player, hand);
        AbstractContainerMenu menu = player.containerMenu;
        if (!(menu instanceof AbstractBackpackMenu backpackMenu)) {
            throw new GameTestAssertException("Expected a backpack menu, got " + menu);
        }
        return backpackMenu;
    }

    private static ItemStack withId(Item item) {
        ItemStack stack = new ItemStack(item);
        BackpackItem.getOrCreateId(stack);
        return stack;
    }

    private static Optional<ItemStack> craft(ServerLevel level, ItemStack... grid) {
        NonNullList<ItemStack> items = NonNullList.withSize(9, ItemStack.EMPTY);
        for (int i = 0; i < grid.length; i++) {
            items.set(i, grid[i].copy());
        }
        // The container is never changed here, so it needs no menu.
        TransientCraftingContainer container = new TransientCraftingContainer(null, 3, 3, items);
        return level.getRecipeManager().getRecipeFor(RecipeType.CRAFTING, container, level)
                .map(recipe -> recipe.assemble(container, level.registryAccess()));
    }

    private static ItemStack[] ringGrid(Item outer, ItemStack center) {
        ItemStack o = new ItemStack(outer);
        return new ItemStack[]{o, o, o, o, center, o, o, o, o};
    }

    private static boolean hasKey(List<Component> lines, String key) {
        for (Component line : lines) {
            if (line.getContents() instanceof TranslatableContents contents && contents.getKey().equals(key)) {
                return true;
            }
            for (Component sibling : line.getSiblings()) {
                if (sibling.getContents() instanceof TranslatableContents contents && contents.getKey().equals(key)) {
                    return true;
                }
            }
        }
        return false;
    }

    // Recipes

    @GameTest(template = EMPTY)
    public static void recipesAreLoaded(GameTestHelper helper) {
        int vanilla = 0;
        int shaped = 0;
        int shapeless = 0;
        for (Recipe<?> recipe : helper.getLevel().getRecipeManager().getRecipes()) {
            if (!recipe.getId().getNamespace().equals(BackpackMod.MOD_ID)) {
                continue;
            }
            if (recipe instanceof KeepNbtShapedRecipe) {
                shaped++;
            } else if (recipe instanceof KeepNbtShapelessRecipe) {
                shapeless++;
            } else {
                vanilla++;
            }
        }
        check(vanilla == 39, "Expected 39 shaped and smelting recipes, found " + vanilla);
        check(shaped == 18, "Expected 18 upgrade recipes, found " + shaped);
        check(shapeless == 36, "Expected 36 recolor, undye and intelligent recipes, found " + shapeless);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void shapedRecipesMakeNewBackpacks(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        ItemStack[] grid = ringGrid(Items.LEATHER, ItemStack.EMPTY);
        Optional<ItemStack> plain = craft(level, grid);
        check(plain.isPresent() && plain.get().is(ModItems.BACKPACK.get()) && !plain.get().hasTag(), "Leather ring should make a plain backpack without NBT");
        Optional<ItemStack> red = craft(level, ringGrid(Items.LEATHER, new ItemStack(Items.RED_DYE)));
        check(red.isPresent() && red.get().is(ModItems.COLORED_BACKPACKS.get(DyeColor.RED).get()), "Leather ring around red dye should make a red backpack");
        Optional<ItemStack> ender = craft(level, ringGrid(Items.LEATHER, new ItemStack(Items.ENDER_CHEST)));
        check(ender.isPresent() && ender.get().is(ModItems.ENDER_BACKPACK.get()), "Leather ring around an ender chest should make the ender backpack");
        Optional<ItemStack> bigWorkbench = craft(level, ringGrid(ModItems.TANNED_LEATHER.get(), new ItemStack(Items.CRAFTING_TABLE)));
        check(bigWorkbench.isPresent() && bigWorkbench.get().is(ModItems.BIG_WORKBENCH_BACKPACK.get()), "Tanned leather around a crafting table should make the big workbench backpack");
        ItemStack s = new ItemStack(Items.STRING);
        ItemStack l = new ItemStack(Items.LEATHER);
        Optional<ItemStack> bound = craft(level, s, s, s, l, s, l, s, s, s);
        check(bound.isPresent() && bound.get().is(ModItems.BOUND_LEATHER.get()), "String and leather should make bound leather");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void recolorKeepsIdAndName(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        ItemStack black = withId(ModItems.COLORED_BACKPACKS.get(DyeColor.BLACK).get());
        black.setHoverName(RenameBackpackPacket.nameComponent("Tools"));
        UUID id = BackpackItem.getId(black);
        Optional<ItemStack> red = craft(level, ItemStack.EMPTY, black, ItemStack.EMPTY, new ItemStack(Items.RED_DYE));
        check(red.isPresent() && red.get().is(ModItems.COLORED_BACKPACKS.get(DyeColor.RED).get()), "Black backpack and red dye should make a red backpack");
        check(id.equals(BackpackItem.getId(red.get())), "Recoloring must keep the backpack UUID");
        check(red.get().getHoverName().getString().equals("Tools"), "Recoloring must keep the custom name");
        Optional<ItemStack> same = craft(level, black, new ItemStack(Items.BLACK_DYE));
        check(same.isPresent() && id.equals(BackpackItem.getId(same.get())), "Dyeing to the same color is allowed");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void undyeFollowsTheTier(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        ItemStack red = withId(ModItems.COLORED_BACKPACKS.get(DyeColor.RED).get());
        ItemStack bigRed = withId(ModItems.BIG_COLORED_BACKPACKS.get(DyeColor.RED).get());
        ItemStack tanned = new ItemStack(ModItems.TANNED_LEATHER.get());
        ItemStack leather = new ItemStack(Items.LEATHER);
        Optional<ItemStack> plain = craft(level, red, leather);
        check(plain.isPresent() && plain.get().is(ModItems.BACKPACK.get()) && BackpackItem.getId(red).equals(BackpackItem.getId(plain.get())),
                "Leather should undye a normal backpack and keep its UUID");
        Optional<ItemStack> bigPlain = craft(level, bigRed, tanned);
        check(bigPlain.isPresent() && bigPlain.get().is(ModItems.BIG_BACKPACK.get()), "Tanned leather should undye a big backpack");
        check(craft(level, red, tanned).isEmpty(), "Tanned leather must not undye a normal backpack");
        check(craft(level, bigRed, leather).isEmpty(), "Leather must not undye a big backpack");
        check(craft(level, withId(ModItems.WORKBENCH_BACKPACK.get()), new ItemStack(Items.RED_DYE)).isEmpty(), "Workbench backpacks cannot be dyed");
        check(craft(level, new ItemStack(ModItems.ENDER_BACKPACK.get()), new ItemStack(Items.RED_DYE)).isEmpty(), "The ender backpack cannot be dyed");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void upgradeKeepsNbt(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        ItemStack black = withId(ModItems.COLORED_BACKPACKS.get(DyeColor.BLACK).get());
        Optional<ItemStack> big = craft(level, ringGrid(ModItems.TANNED_LEATHER.get(), black));
        check(big.isPresent() && big.get().is(ModItems.BIG_COLORED_BACKPACKS.get(DyeColor.BLACK).get()), "Upgrade should make a big black backpack");
        check(BackpackItem.getId(black).equals(BackpackItem.getId(big.get())), "The upgrade must keep the UUID");
        ItemStack workbench = withId(ModItems.WORKBENCH_BACKPACK.get());
        workbench.getOrCreateTag().putBoolean(BackpackItem.TAG_INTELLIGENT, true);
        Optional<ItemStack> bigWorkbench = craft(level, ringGrid(ModItems.TANNED_LEATHER.get(), workbench));
        check(bigWorkbench.isPresent() && bigWorkbench.get().is(ModItems.BIG_WORKBENCH_BACKPACK.get()), "Upgrade should make a big workbench backpack");
        check(BackpackItem.isIntelligent(bigWorkbench.get()), "The upgrade must keep the intelligent flag");
        check(craft(level, ringGrid(ModItems.TANNED_LEATHER.get(), new ItemStack(ModItems.ENDER_BACKPACK.get()))).isEmpty(), "The ender backpack has no upgrade");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void bookMakesWorkbenchIntelligent(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        ItemStack workbench = withId(ModItems.WORKBENCH_BACKPACK.get());
        Optional<ItemStack> smart = craft(level, new ItemStack(Items.WRITABLE_BOOK), ItemStack.EMPTY, workbench);
        check(smart.isPresent() && smart.get().is(ModItems.WORKBENCH_BACKPACK.get()), "Book and quill with a workbench backpack should match");
        check(BackpackItem.isIntelligent(smart.get()), "The result must be intelligent");
        check(BackpackItem.getId(workbench).equals(BackpackItem.getId(smart.get())), "The intelligent recipe must keep the UUID");
        check(craft(level, withId(ModItems.BACKPACK.get()), new ItemStack(Items.WRITABLE_BOOK)).isEmpty(), "Only workbench backpacks become intelligent");
        helper.succeed();
    }

    // Storage

    @GameTest(template = EMPTY)
    public static void savedDataRoundTrip(GameTestHelper helper) {
        UUID id = UUID.randomUUID();
        BackpackData data = BackpackStorage.get(helper.getLevel().getServer(), id);
        check(data == BackpackStorage.get(helper.getLevel().getServer(), id), "The server must keep one live instance per backpack");
        data.storage().ensureSize(54);
        data.storage().setItem(0, new ItemStack(Items.DIAMOND, 12));
        data.storage().setItem(53, new ItemStack(Items.STONE, 64));
        data.grid().setItem(4, new ItemStack(Items.OAK_PLANKS));
        data.saveRecipe(2, new ItemStack(Items.CRAFTING_TABLE));
        check(data.isDirty(), "Changes must mark the data dirty");
        BackpackData loaded = BackpackData.load(data.save(new CompoundTag()));
        check(loaded.storage().getContainerSize() == 54, "Size must survive saving");
        check(ItemStack.matches(loaded.storage().getItem(0), new ItemStack(Items.DIAMOND, 12)), "Slot 0 must survive saving");
        check(ItemStack.matches(loaded.storage().getItem(53), new ItemStack(Items.STONE, 64)), "Slot 53 must survive saving");
        check(loaded.grid().getItem(4).is(Items.OAK_PLANKS), "The ghost grid must survive saving");
        check(loaded.recipeIcons().getItem(2).is(Items.CRAFTING_TABLE), "Recipe icons must survive saving");
        loaded.clearGrid();
        loaded.loadRecipe(2);
        check(loaded.grid().getItem(4).is(Items.OAK_PLANKS), "Saved recipe grids must survive saving");
        check(!loaded.storage().ensureSize(27), "Storage must never shrink");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void upgradedBackpackKeepsItems(GameTestHelper helper) {
        FakePlayer player = player(helper);
        ItemStack small = new ItemStack(ModItems.BACKPACK.get());
        player.getInventory().setItem(0, small);
        AbstractBackpackMenu menu = open(player, InteractionHand.MAIN_HAND);
        check(menu instanceof BackpackMenu && menu.storageStart() == 0 && menu.inventoryStart() == 27, "A small backpack has 27 storage slots");
        for (int i = 0; i < 27; i++) {
            menu.getSlot(i).set(new ItemStack(Items.COBBLESTONE, i + 1));
        }
        menu.broadcastChanges();
        check(BackpackItem.getUsedSlots(player.getInventory().getItem(0)) == 27, "The held item must count 27 used slots");
        player.closeContainer();
        Optional<ItemStack> big = craft(helper.getLevel(), ringGrid(ModItems.TANNED_LEATHER.get(), player.getInventory().getItem(0)));
        check(big.isPresent(), "Upgrade recipe should match the opened backpack");
        player.getInventory().setItem(0, big.get());
        AbstractBackpackMenu bigMenu = open(player, InteractionHand.MAIN_HAND);
        check(bigMenu.inventoryStart() == 54, "A big backpack has 54 storage slots");
        for (int i = 0; i < 27; i++) {
            ItemStack stack = bigMenu.getSlot(i).getItem();
            check(stack.is(Items.COBBLESTONE) && stack.getCount() == i + 1, "Slot " + i + " lost its items in the upgrade");
        }
        for (int i = 27; i < 54; i++) {
            check(bigMenu.getSlot(i).getItem().isEmpty(), "New slot " + i + " must be empty");
        }
        player.closeContainer();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void twoMenusShareOneBackpack(GameTestHelper helper) {
        FakePlayer first = player(helper);
        FakePlayer second = player(helper);
        ItemStack stack = withId(ModItems.BACKPACK.get());
        first.getInventory().setItem(0, stack.copy());
        second.getInventory().setItem(0, stack.copy());
        AbstractBackpackMenu a = open(first, InteractionHand.MAIN_HAND);
        AbstractBackpackMenu b = open(second, InteractionHand.MAIN_HAND);
        a.getSlot(5).set(new ItemStack(Items.EMERALD, 3));
        check(ItemStack.matches(b.getSlot(5).getItem(), new ItemStack(Items.EMERALD, 3)), "Both menus must show the same live stacks");
        first.closeContainer();
        second.closeContainer();
        helper.succeed();
    }

    // Menu rules

    @GameTest(template = EMPTY)
    public static void storageRefusesBackpacks(GameTestHelper helper) {
        FakePlayer player = player(helper);
        player.getInventory().setItem(0, new ItemStack(ModItems.BACKPACK.get()));
        player.getInventory().setItem(1, new ItemStack(ModItems.BIG_BACKPACK.get()));
        player.getInventory().setItem(9, new ItemStack(ModItems.ENDER_BACKPACK.get()));
        player.getInventory().setItem(10, new ItemStack(Items.STONE, 20));
        AbstractBackpackMenu menu = open(player, InteractionHand.MAIN_HAND);

        menu.setCarried(new ItemStack(ModItems.WORKBENCH_BACKPACK.get()));
        menu.clicked(0, 0, ClickType.PICKUP, player);
        check(menu.getSlot(0).getItem().isEmpty() && menu.getCarried().is(ModItems.WORKBENCH_BACKPACK.get()), "A click must not put a backpack into storage");

        menu.clicked(0, 0, ClickType.QUICK_CRAFT, player);
        menu.clicked(1, 1, ClickType.QUICK_CRAFT, player);
        menu.clicked(-999, 2, ClickType.QUICK_CRAFT, player);
        check(menu.getSlot(1).getItem().isEmpty() && menu.getCarried().is(ModItems.WORKBENCH_BACKPACK.get()), "Dragging must not put a backpack into storage");
        menu.setCarried(ItemStack.EMPTY);

        menu.clicked(menu.inventoryStart(), 0, ClickType.QUICK_MOVE, player);
        check(player.getInventory().contains(new ItemStack(ModItems.ENDER_BACKPACK.get())), "Shift click must keep the backpack in the player inventory");

        menu.clicked(2, 1, ClickType.SWAP, player);
        check(menu.getSlot(2).getItem().isEmpty() && player.getInventory().getItem(1).is(ModItems.BIG_BACKPACK.get()), "A number key must not swap a backpack into storage");

        menu.clicked(menu.inventoryStart() + 1, 0, ClickType.QUICK_MOVE, player);
        check(menu.getSlot(0).getItem().is(Items.STONE) && menu.getSlot(0).getItem().getCount() == 20, "Shift click must still move other items into storage");
        for (int i = 0; i < 27; i++) {
            check(!(menu.getSlot(i).getItem().getItem() instanceof BackpackItem), "Storage slot " + i + " holds a backpack");
        }
        player.closeContainer();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void heldBackpackIsLocked(GameTestHelper helper) {
        FakePlayer player = player(helper);
        player.getInventory().selected = 3;
        player.getInventory().setItem(3, new ItemStack(ModItems.BACKPACK.get()));
        player.getInventory().setItem(10, new ItemStack(Items.STONE, 5));
        AbstractBackpackMenu menu = open(player, InteractionHand.MAIN_HAND);
        check(menu.lockedSlot() == 3, "The locked slot must be the selected hotbar slot");
        int lockedIndex = menu.hotbarStart() + 3;
        UUID id = BackpackItem.getId(player.getInventory().getItem(3));

        menu.clicked(lockedIndex, 0, ClickType.PICKUP, player);
        check(menu.getCarried().isEmpty() && player.getInventory().getItem(3).is(ModItems.BACKPACK.get()), "The held backpack must not be picked up");
        menu.clicked(lockedIndex, 0, ClickType.QUICK_MOVE, player);
        check(player.getInventory().getItem(3).is(ModItems.BACKPACK.get()), "The held backpack must not be shift clicked away");
        menu.clicked(lockedIndex, 1, ClickType.THROW, player);
        check(player.getInventory().getItem(3).is(ModItems.BACKPACK.get()), "The held backpack must not be thrown");
        menu.clicked(lockedIndex, 0, ClickType.SWAP, player);
        check(player.getInventory().getItem(3).is(ModItems.BACKPACK.get()), "The held backpack must not be swapped by its own slot");
        // Player slot 9 is empty and takes a backpack, so only the lock keeps it in hotbar slot 3.
        Slot free = menu.getSlot(menu.inventoryStart());
        check(free.getItem().isEmpty() && free.mayPlace(player.getInventory().getItem(3)), "Player slot 9 must be empty and take a backpack");
        menu.clicked(menu.inventoryStart(), 3, ClickType.SWAP, player);
        check(player.getInventory().getItem(3).is(ModItems.BACKPACK.get()) && free.getItem().isEmpty(), "Its number key must not move the held backpack");
        menu.clicked(menu.inventoryStart() + 1, 0, ClickType.PICKUP, player);
        menu.clicked(lockedIndex, 0, ClickType.PICKUP, player);
        check(menu.getCarried().is(Items.STONE) && player.getInventory().getItem(3).is(ModItems.BACKPACK.get()), "Nothing must be placed into the locked slot");
        menu.setCarried(ItemStack.EMPTY);

        check(menu.stillValid(player), "The menu must be valid while the backpack is held");
        player.getInventory().setItem(3, withId(ModItems.BACKPACK.get()));
        check(!menu.stillValid(player), "Another backpack in the slot must close the menu");
        ItemStack original = new ItemStack(ModItems.BACKPACK.get());
        original.getOrCreateTag().putUUID(BackpackItem.TAG_ID, id);
        player.getInventory().setItem(3, original);
        check(menu.stillValid(player), "The same backpack in the slot keeps the menu valid");
        player.getInventory().setItem(3, ItemStack.EMPTY);
        check(!menu.stillValid(player), "An empty slot must close the menu");
        player.closeContainer();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void offhandBackpackIsLocked(GameTestHelper helper) {
        FakePlayer player = player(helper);
        player.getInventory().setItem(Inventory.SLOT_OFFHAND, new ItemStack(ModItems.BACKPACK.get()));
        player.getInventory().setItem(0, new ItemStack(Items.STONE, 7));
        AbstractBackpackMenu menu = open(player, InteractionHand.OFF_HAND);
        check(menu.lockedSlot() == Inventory.SLOT_OFFHAND, "The locked slot must be the offhand");
        // Player slot 9 is empty and takes a backpack, so only the lock keeps it in the offhand.
        Slot free = menu.getSlot(menu.inventoryStart());
        check(free.getItem().isEmpty() && free.mayPlace(player.getOffhandItem()), "Player slot 9 must be empty and take a backpack");
        menu.clicked(menu.inventoryStart(), Inventory.SLOT_OFFHAND, ClickType.SWAP, player);
        check(player.getOffhandItem().is(ModItems.BACKPACK.get()) && free.getItem().isEmpty(), "The offhand key must not move the held backpack");
        menu.clicked(1, 0, ClickType.SWAP, player);
        check(menu.getSlot(1).getItem().is(Items.STONE), "Other number keys still work");
        check(menu.stillValid(player), "The menu must be valid while the backpack is in the offhand");
        player.getInventory().setItem(Inventory.SLOT_OFFHAND, ItemStack.EMPTY);
        check(!menu.stillValid(player), "Removing the backpack from the offhand must close the menu");
        player.closeContainer();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void enderBackpackShowsEnderChest(GameTestHelper helper) {
        FakePlayer player = player(helper);
        player.getEnderChestInventory().setItem(3, new ItemStack(Items.DIAMOND, 2));
        player.getInventory().setItem(0, new ItemStack(ModItems.ENDER_BACKPACK.get()));
        player.getInventory().setItem(9, new ItemStack(Items.GOLD_INGOT, 4));
        AbstractBackpackMenu menu = open(player, InteractionHand.MAIN_HAND);
        check(menu instanceof BackpackMenu && menu.inventoryStart() == 27, "The ender backpack shows 27 slots");
        check(ItemStack.matches(menu.getSlot(3).getItem(), new ItemStack(Items.DIAMOND, 2)), "The ender backpack must show the ender chest");
        menu.clicked(menu.inventoryStart(), 0, ClickType.QUICK_MOVE, player);
        check(player.getEnderChestInventory().getItem(0).is(Items.GOLD_INGOT), "Items must go into the ender chest inventory");
        check(!player.getInventory().getItem(0).hasTag(), "The ender backpack needs no UUID");
        player.getInventory().setItem(0, ItemStack.EMPTY);
        check(menu.stillValid(player), "The ender backpack menu is always valid");
        player.closeContainer();
        helper.succeed();
    }

    // Workbench

    private static void setGhosts(AbstractBackpackMenu menu, FakePlayer player, ItemStack ghost, int... gridSlots) {
        menu.setCarried(ghost.copy());
        for (int slot : gridSlots) {
            menu.clicked(WorkbenchBackpackMenu.GRID_START + slot, 0, ClickType.PICKUP, player);
        }
        check(ItemStack.matches(menu.getCarried(), ghost), "Ghost clicks must not use up the cursor stack");
        menu.setCarried(ItemStack.EMPTY);
        menu.broadcastChanges();
    }

    @GameTest(template = EMPTY)
    public static void workbenchCraftsFromStorage(GameTestHelper helper) {
        FakePlayer player = player(helper);
        player.getInventory().setItem(0, new ItemStack(ModItems.WORKBENCH_BACKPACK.get()));
        AbstractBackpackMenu menu = open(player, InteractionHand.MAIN_HAND);
        check(menu instanceof WorkbenchBackpackMenu && menu.storageStart() == 10 && menu.inventoryStart() == 19, "Workbench layout is result, grid, 9 storage slots");
        setGhosts(menu, player, new ItemStack(Items.OAK_PLANKS, 5), 0, 1, 3, 4);
        check(menu.getSlot(WorkbenchBackpackMenu.GRID_START).getItem().getCount() == 1, "Ghost stacks hold one item");
        check(menu.getSlot(WorkbenchBackpackMenu.RESULT_SLOT).getItem().is(Items.CRAFTING_TABLE), "The result must show the crafting table");

        menu.clicked(WorkbenchBackpackMenu.RESULT_SLOT, 0, ClickType.PICKUP, player);
        check(menu.getCarried().isEmpty(), "Without ingredients in storage nothing can be taken");
        check(menu.getSlot(WorkbenchBackpackMenu.RESULT_SLOT).getItem().is(Items.CRAFTING_TABLE), "The result keeps showing");

        menu.getSlot(menu.storageStart() + 2).set(new ItemStack(Items.SPRUCE_PLANKS, 4));
        menu.clicked(WorkbenchBackpackMenu.RESULT_SLOT, 0, ClickType.PICKUP, player);
        check(menu.getCarried().is(Items.CRAFTING_TABLE) && menu.getCarried().getCount() == 1, "Spruce planks in storage stand in for the oak ghosts");
        check(menu.getSlot(menu.storageStart() + 2).getItem().isEmpty(), "Crafting must use up the four planks");
        menu.setCarried(ItemStack.EMPTY);

        menu.getSlot(menu.storageStart()).set(new ItemStack(Items.OAK_PLANKS, 9));
        menu.clicked(WorkbenchBackpackMenu.RESULT_SLOT, 0, ClickType.QUICK_MOVE, player);
        int tables = 0;
        int planks = 0;
        for (int i = menu.storageStart(); i < menu.inventoryStart(); i++) {
            ItemStack stack = menu.getSlot(i).getItem();
            if (stack.is(Items.CRAFTING_TABLE)) {
                tables += stack.getCount();
            } else if (stack.is(Items.OAK_PLANKS)) {
                planks += stack.getCount();
            }
        }
        check(tables == 2 && planks == 1, "Shift click should craft twice into storage, got " + tables + " tables and " + planks + " planks");

        menu.clickMenuButton(player, WorkbenchBackpackMenu.BUTTON_CLEAR);
        menu.broadcastChanges();
        for (int i = WorkbenchBackpackMenu.GRID_START; i < WorkbenchBackpackMenu.GRID_END; i++) {
            check(menu.getSlot(i).getItem().isEmpty(), "Clear must empty the ghost grid");
        }
        check(menu.getSlot(WorkbenchBackpackMenu.RESULT_SLOT).getItem().isEmpty(), "An empty grid shows no result");
        player.closeContainer();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void workbenchReturnsContainerItems(GameTestHelper helper) {
        FakePlayer player = player(helper);
        player.getInventory().setItem(0, new ItemStack(ModItems.BIG_WORKBENCH_BACKPACK.get()));
        AbstractBackpackMenu menu = open(player, InteractionHand.MAIN_HAND);
        check(menu.inventoryStart() - menu.storageStart() == 18, "The big workbench backpack has 18 storage slots");
        setGhosts(menu, player, new ItemStack(Items.HONEY_BOTTLE), 4);
        check(menu.getSlot(WorkbenchBackpackMenu.RESULT_SLOT).getItem().is(Items.SUGAR), "Honey bottle shows sugar");
        menu.getSlot(menu.storageStart()).set(new ItemStack(Items.HONEY_BOTTLE, 2));
        menu.clicked(WorkbenchBackpackMenu.RESULT_SLOT, 0, ClickType.QUICK_MOVE, player);
        int sugar = 0;
        int bottles = 0;
        int honey = 0;
        for (int i = menu.storageStart(); i < menu.inventoryStart(); i++) {
            ItemStack stack = menu.getSlot(i).getItem();
            if (stack.is(Items.SUGAR)) {
                sugar += stack.getCount();
            } else if (stack.is(Items.GLASS_BOTTLE)) {
                bottles += stack.getCount();
            } else if (stack.is(Items.HONEY_BOTTLE)) {
                honey += stack.getCount();
            }
        }
        check(sugar == 6 && bottles == 2 && honey == 0, "Expected 6 sugar and 2 bottles in storage, got " + sugar + " sugar, " + bottles + " bottles and " + honey + " honey");
        player.closeContainer();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void intelligentWorkbenchRemembersRecipes(GameTestHelper helper) {
        FakePlayer player = player(helper);
        ItemStack stack = new ItemStack(ModItems.WORKBENCH_BACKPACK.get());
        stack.getOrCreateTag().putBoolean(BackpackItem.TAG_INTELLIGENT, true);
        player.getInventory().setItem(0, stack);
        AbstractBackpackMenu opened = open(player, InteractionHand.MAIN_HAND);
        check(opened instanceof WorkbenchBackpackMenu workbench && workbench.isIntelligent(), "The backpack must open as intelligent");
        check(opened.storageStart() == WorkbenchBackpackMenu.RECIPES_END, "Storage follows the nine recipe slots");
        setGhosts(opened, player, new ItemStack(Items.OAK_PLANKS), 0, 3);
        check(opened.getSlot(WorkbenchBackpackMenu.RESULT_SLOT).getItem().is(Items.STICK), "Two planks show sticks");
        opened.clickMenuButton(player, WorkbenchBackpackMenu.BUTTON_SAVE);
        opened.clicked(WorkbenchBackpackMenu.RECIPES_START + 2, 0, ClickType.PICKUP, player);
        check(opened.getSlot(WorkbenchBackpackMenu.RECIPES_START + 2).getItem().is(Items.STICK), "Save mode must store the result as icon");
        opened.clickMenuButton(player, WorkbenchBackpackMenu.BUTTON_CLEAR);
        opened.broadcastChanges();
        check(opened.getSlot(WorkbenchBackpackMenu.GRID_START).getItem().isEmpty(), "Clear must empty the grid");
        opened.clicked(WorkbenchBackpackMenu.RECIPES_START + 2, 0, ClickType.PICKUP, player);
        opened.broadcastChanges();
        check(opened.getSlot(WorkbenchBackpackMenu.GRID_START).getItem().is(Items.OAK_PLANKS)
                && opened.getSlot(WorkbenchBackpackMenu.GRID_START + 3).getItem().is(Items.OAK_PLANKS), "A recipe click must load the saved grid");
        check(opened.getSlot(WorkbenchBackpackMenu.RESULT_SLOT).getItem().is(Items.STICK), "The loaded grid shows its result");
        opened.clicked(WorkbenchBackpackMenu.RECIPES_START + 5, 0, ClickType.PICKUP, player);
        opened.broadcastChanges();
        check(opened.getSlot(WorkbenchBackpackMenu.GRID_START).getItem().isEmpty(), "An empty recipe clears the grid");
        player.closeContainer();
        helper.succeed();
    }

    /**
     * Quark's restock and sort buttons wrap the container of the first slot outside the player
     * inventory in an InvWrapper and take from it without clicking the slot. The containers of
     * the result, ghost and recipe slots must therefore give nothing away and take nothing in.
     */
    @GameTest(template = EMPTY)
    public static void workbenchSlotContainersGiveNothingAway(GameTestHelper helper) {
        for (Item kind : List.of(ModItems.WORKBENCH_BACKPACK.get(), ModItems.BIG_WORKBENCH_BACKPACK.get())) {
            for (boolean intelligent : new boolean[]{false, true}) {
                String name = kind + (intelligent ? " (intelligent)" : "");
                FakePlayer player = player(helper);
                ItemStack backpack = new ItemStack(kind);
                if (intelligent) {
                    backpack.getOrCreateTag().putBoolean(BackpackItem.TAG_INTELLIGENT, true);
                }
                player.getInventory().setItem(0, backpack);
                AbstractBackpackMenu menu = open(player, InteractionHand.MAIN_HAND);
                setGhosts(menu, player, new ItemStack(Items.DIAMOND), 0, 1, 2, 3, 4, 5, 6, 7, 8);
                check(menu.getSlot(WorkbenchBackpackMenu.RESULT_SLOT).getItem().is(Items.DIAMOND_BLOCK), name + ": nine diamond ghosts must show a diamond block");
                if (intelligent) {
                    menu.clickMenuButton(player, WorkbenchBackpackMenu.BUTTON_SAVE);
                    menu.clicked(WorkbenchBackpackMenu.RECIPES_START, 0, ClickType.PICKUP, player);
                    check(menu.getSlot(WorkbenchBackpackMenu.RECIPES_START).getItem().is(Items.DIAMOND_BLOCK), name + ": the saved recipe must show a diamond block");
                }
                for (int index = 0; index < menu.slots.size(); index++) {
                    Slot slot = menu.getSlot(index);
                    if (slot.container == player.getInventory()) {
                        continue;
                    }
                    IItemHandler handler = new InvWrapper(slot.container);
                    for (int i = 0; i < handler.getSlots(); i++) {
                        ItemStack taken = handler.extractItem(i, 64, false);
                        check(taken.isEmpty(), name + ": the container of menu slot " + index + " gave away " + taken);
                        if (index < menu.storageStart()) {
                            ItemStack left = handler.insertItem(i, new ItemStack(Items.COBBLESTONE, 64), false);
                            check(left.getCount() == 64, name + ": the container of menu slot " + index + " took " + (64 - left.getCount()) + " cobblestone");
                        }
                    }
                }
                check(menu.getSlot(WorkbenchBackpackMenu.RESULT_SLOT).getItem().is(Items.DIAMOND_BLOCK), name + ": the result must still show the diamond block");
                check(menu.getSlot(WorkbenchBackpackMenu.GRID_START + 8).getItem().is(Items.DIAMOND), name + ": the ghosts must still show");
                for (int i = 1; i < player.getInventory().getContainerSize(); i++) {
                    check(player.getInventory().getItem(i).isEmpty(), name + ": the player must get nothing, found " + player.getInventory().getItem(i));
                }
                for (int i = menu.storageStart(); i < menu.inventoryStart(); i++) {
                    check(menu.getSlot(i).getItem().isEmpty(), name + ": the storage must stay empty");
                }
                player.closeContainer();
            }
        }
        helper.succeed();
    }

    // Item

    @GameTest(template = EMPTY)
    public static void rightClickOpensButNotForFakePlayers(GameTestHelper helper) {
        ServerPlayer player = plainPlayer(helper);
        player.getInventory().setItem(0, new ItemStack(ModItems.BIG_BACKPACK.get()));
        player.getInventory().getItem(0).use(helper.getLevel(), player, InteractionHand.MAIN_HAND);
        check(player.containerMenu instanceof BackpackMenu, "Right click must open the backpack");
        check(BackpackItem.getId(player.getInventory().getItem(0)) != null, "Opening must assign a UUID");
        player.closeContainer();
        player.setShiftKeyDown(true);
        player.getInventory().getItem(0).use(helper.getLevel(), player, InteractionHand.MAIN_HAND);
        check(player.containerMenu == player.inventoryMenu, "Sneaking must not open the backpack on the server");

        // A Create deployer uses items through a fake player, whose connection never sends.
        FakePlayer machine = player(helper);
        machine.getInventory().setItem(0, new ItemStack(ModItems.BIG_BACKPACK.get()));
        InteractionResultHolder<ItemStack> used = machine.getInventory().getItem(0).use(helper.getLevel(), machine, InteractionHand.MAIN_HAND);
        check(used.getResult() == InteractionResult.PASS, "A fake player's right click must pass, got " + used.getResult());
        check(machine.containerMenu == machine.inventoryMenu, "A fake player must not open a backpack");
        check(BackpackItem.getId(machine.getInventory().getItem(0)) == null, "A fake player must not give the backpack a UUID");
        machine.setShiftKeyDown(true);
        machine.getInventory().getItem(0).use(helper.getLevel(), machine, InteractionHand.MAIN_HAND);
        check(machine.containerMenu == machine.inventoryMenu, "A sneaking fake player must not open a backpack either");
        machine.setShiftKeyDown(false);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void tooltipWorksOnTheServer(GameTestHelper helper) {
        ItemStack stack = new ItemStack(ModItems.WORKBENCH_BACKPACK.get());
        stack.getOrCreateTag().putBoolean(BackpackItem.TAG_INTELLIGENT, true);
        List<Component> lines = stack.getTooltipLines(null, TooltipFlag.NORMAL);
        check(hasKey(lines, "tooltip.backpack.more_information"), "Without Shift the tooltip asks for Shift");
        check(hasKey(lines, "tooltip.backpack.intelligent"), "Intelligent workbench backpacks say so");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void renameRules(GameTestHelper helper) {
        check("Tools".equals(RenameBackpackPacket.validName("  Tools  ")), "Names are trimmed");
        check(RenameBackpackPacket.validName("   ") == null, "Empty names are refused");
        check(RenameBackpackPacket.validName("x".repeat(33)) == null, "Names longer than 32 characters are refused");
        check("x".repeat(32).equals(RenameBackpackPacket.validName("x".repeat(32))), "32 characters are allowed");
        check("ab".equals(RenameBackpackPacket.validName("a§b")), "Formatting codes are removed");
        Component name = RenameBackpackPacket.nameComponent("Tools");
        check(name.getStyle().equals(Style.EMPTY.withItalic(false)), "Custom names are not italic");
        helper.succeed();
    }
}
