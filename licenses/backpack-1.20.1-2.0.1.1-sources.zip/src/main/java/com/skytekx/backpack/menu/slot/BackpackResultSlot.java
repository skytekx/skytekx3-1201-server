package com.skytekx.backpack.menu.slot;

import com.skytekx.backpack.menu.WorkbenchBackpackMenu;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * The result slot of a workbench backpack. It shows the output of the ghost grid, also while the
 * storage lacks the ingredients, as 2.0.1 did. Like every {@link DisplaySlot} it keeps that
 * preview out of its public container, so code that wraps slot containers gets nothing from it.
 * Through the slot itself the preview can only be taken while the menu handles a click on it and
 * has checked that the storage holds the ingredients, and taking it uses them up.
 */
public class BackpackResultSlot extends DisplaySlot {
    private final WorkbenchBackpackMenu menu;

    public BackpackResultSlot(WorkbenchBackpackMenu menu, EmptyContainer placeholder, Container result, int x, int y) {
        super(placeholder, result, 0, x, y);
        this.menu = menu;
    }

    @Override
    public boolean mayPickup(Player player) {
        return menu.isTakingResult();
    }

    /** Takes the whole preview, as the vanilla result slot does, but only during a checked click. */
    @Override
    public ItemStack remove(int amount) {
        return menu.isTakingResult() ? removeShown(amount) : ItemStack.EMPTY;
    }

    @Override
    public void onTake(Player player, ItemStack stack) {
        menu.onResultTaken(player, stack);
        super.onTake(player, stack);
    }
}
