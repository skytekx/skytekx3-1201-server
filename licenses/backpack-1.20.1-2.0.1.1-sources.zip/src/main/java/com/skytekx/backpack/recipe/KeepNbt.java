package com.skytekx.backpack.recipe;

import com.skytekx.backpack.item.BackpackItem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;

/** Copies the NBT of the backpack in a crafting grid onto the result, as 2.0.1 did. */
final class KeepNbt {
    private KeepNbt() {
    }

    /**
     * Puts the tag of the first backpack in the grid onto the result. Tags of the result
     * itself, such as the intelligent flag, win over the copied ones.
     */
    static ItemStack apply(CraftingContainer container, ItemStack result) {
        for (int i = 0; i < container.getContainerSize(); i++) {
            ItemStack input = container.getItem(i);
            if (input.getItem() instanceof BackpackItem) {
                CompoundTag inputTag = input.getTag();
                if (inputTag != null) {
                    CompoundTag merged = inputTag.copy();
                    CompoundTag resultTag = result.getTag();
                    if (resultTag != null) {
                        merged.merge(resultTag);
                    }
                    result.setTag(merged);
                }
                return result;
            }
        }
        return result;
    }
}
