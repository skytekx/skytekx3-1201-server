package com.skytekx.backpack.menu.slot;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/**
 * A slot that shows a stack which is no real item: a ghost item, a saved recipe icon or the
 * crafting preview. The stack lives in a container that only this slot can reach. The public
 * {@code container} field points to an {@link EmptyContainer} instead, so code that wraps the
 * container of a slot rather than going through the slot, as the restock and sort buttons of
 * Quark do, finds nothing to take and no room to insert. Vanilla syncs, draws and clicks slots
 * through the slot methods, which read and write the shown stack.
 *
 * <p>Nothing can be picked up from a display slot or placed into it. The menu changes the
 * shown stacks with {@link #set}.
 */
public abstract class DisplaySlot extends Slot {
    private final Container shown;

    /**
     * The placeholder is the empty container of the slot group and becomes the public
     * {@code container}. The shown container holds the stacks and stays private to the slot.
     */
    protected DisplaySlot(EmptyContainer placeholder, Container shown, int index, int x, int y) {
        super(placeholder, index, x, y);
        this.shown = shown;
    }

    @Override
    public ItemStack getItem() {
        return shown.getItem(getContainerSlot());
    }

    @Override
    public void set(ItemStack stack) {
        shown.setItem(getContainerSlot(), stack);
        setChanged();
    }

    @Override
    public void setChanged() {
        shown.setChanged();
    }

    @Override
    public int getMaxStackSize() {
        return shown.getMaxStackSize();
    }

    /** Gives nothing, since the shown stack is no real item. */
    @Override
    public ItemStack remove(int amount) {
        return ItemStack.EMPTY;
    }

    /** Takes the shown stack, for a subclass that hands it out under its own checks. */
    protected ItemStack removeShown(int amount) {
        return shown.removeItem(getContainerSlot(), amount);
    }

    @Override
    public boolean mayPickup(Player player) {
        return false;
    }

    @Override
    public boolean mayPlace(ItemStack stack) {
        return false;
    }

    @Override
    public boolean allowModification(Player player) {
        return false;
    }
}
