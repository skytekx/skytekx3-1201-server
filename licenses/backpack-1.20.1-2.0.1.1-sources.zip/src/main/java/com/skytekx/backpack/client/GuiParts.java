package com.skytekx.backpack.client;

import com.skytekx.backpack.BackpackMod;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

/** Draws windows and slots from the parts of the original guiCombined.png, as 2.0.1 did. */
final class GuiParts {
    static final ResourceLocation TEXTURE = BackpackMod.id("textures/gui/gui_combined.png");
    static final int LABEL_COLOR = 0x404040;
    private static final int FILL = 0xFFC6C6C6;
    private static final int TILE = 100;

    private GuiParts() {
    }

    /** A window of any size: four corners, repeated edge tiles and the flat gray inside. */
    static void window(GuiGraphics graphics, int x, int y, int width, int height) {
        graphics.blit(TEXTURE, x, y, 0, 0, 4, 4);
        graphics.blit(TEXTURE, x + width - 4, y, 172, 0, 4, 4);
        graphics.blit(TEXTURE, x, y + height - 4, 0, 163, 4, 4);
        graphics.blit(TEXTURE, x + width - 4, y + height - 4, 172, 163, 4, 4);
        for (int offset = 0; offset < width - 8; offset += TILE) {
            int length = Math.min(TILE, width - 8 - offset);
            graphics.blit(TEXTURE, x + 4 + offset, y, 4, 0, length, 4);
            graphics.blit(TEXTURE, x + 4 + offset, y + height - 4, 4, 163, length, 4);
        }
        for (int offset = 0; offset < height - 8; offset += TILE) {
            int length = Math.min(TILE, height - 8 - offset);
            graphics.blit(TEXTURE, x, y + 4 + offset, 0, 4, 4, length);
            graphics.blit(TEXTURE, x + width - 4, y + 4 + offset, 172, 4, 4, length);
        }
        graphics.fill(x + 4, y + 4, x + width - 4, y + height - 4, FILL);
    }

    /** The 18 by 18 slot background for a slot whose item is drawn at x, y. */
    static void slot(GuiGraphics graphics, int x, int y) {
        graphics.blit(TEXTURE, x - 1, y - 1, 201, 0, 18, 18);
    }

    /** The 26 by 26 background of the workbench result slot whose item is drawn at x, y. */
    static void resultSlot(GuiGraphics graphics, int x, int y) {
        graphics.blit(TEXTURE, x - 5, y - 5, 201, 18, 26, 26);
    }

    /** The gray crafting arrow. */
    static void arrow(GuiGraphics graphics, int x, int y) {
        graphics.blit(TEXTURE, x, y, 0, 238, 22, 15);
    }
}
