package com.skytekx.backpack.registry;

import com.skytekx.backpack.BackpackMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BackpackMod.MOD_ID);

    /** The Backpacks tab in the order of 2.0.1, without the dead medium tier. */
    public static final RegistryObject<CreativeModeTab> BACKPACKS = TABS.register("backpacks", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.backpack.backpacks"))
            .icon(() -> new ItemStack(ModItems.BACKPACK.get()))
            .displayItems((parameters, output) -> {
                output.accept(ModItems.BACKPACK.get());
                for (DyeColor color : ModItems.COLOR_ORDER) {
                    output.accept(ModItems.COLORED_BACKPACKS.get(color).get());
                }
                output.accept(ModItems.BIG_BACKPACK.get());
                for (DyeColor color : ModItems.COLOR_ORDER) {
                    output.accept(ModItems.BIG_COLORED_BACKPACKS.get(color).get());
                }
                output.accept(ModItems.ENDER_BACKPACK.get());
                output.accept(ModItems.WORKBENCH_BACKPACK.get());
                output.accept(ModItems.BIG_WORKBENCH_BACKPACK.get());
            })
            .build());

    private ModTabs() {
    }

    /** The leathers sat in the vanilla Materials tab in 2.0.1, which is the Ingredients tab now. */
    public static void addToVanillaTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(ModItems.BOUND_LEATHER);
            event.accept(ModItems.TANNED_LEATHER);
        }
    }
}
