package com.skytekx.backpack.menu.slot;

import com.skytekx.backpack.storage.BackpackRules;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;

/** A storage slot of a backpack. It refuses backpacks and the items of the not allowed tag. */
public class StorageSlot extends Slot {
    public StorageSlot(Container container, int index, int x, int y) {
        super(container, index, x, y);
    }

    @Override
    public boolean mayPlace(ItemStack stack) {
        return BackpackRules.mayStore(stack);
    }
}
