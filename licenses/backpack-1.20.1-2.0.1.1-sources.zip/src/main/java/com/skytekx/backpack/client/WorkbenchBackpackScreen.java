package com.skytekx.backpack.client;

import com.skytekx.backpack.menu.WorkbenchBackpackMenu;
import com.skytekx.backpack.menu.slot.BackpackResultSlot;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

/**
 * The screen of the workbench backpacks. It shows {@code Crafting} instead of the backpack name,
 * as 2.0.1 did, and has the clear button and, on intelligent backpacks, the save button. The
 * keys c and s press them.
 */
public class WorkbenchBackpackScreen extends AbstractContainerScreen<WorkbenchBackpackMenu> {
    private static final Component CRAFTING = Component.translatable("container.crafting");

    public WorkbenchBackpackScreen(WorkbenchBackpackMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
        int rows = menu.kind().storageRows();
        imageWidth = 178;
        imageHeight = 175 + 18 * rows;
        titleLabelY = 6;
        inventoryLabelX = 8;
        inventoryLabelY = 79 + 18 * rows;
    }

    @Override
    protected void init() {
        super.init();
        titleLabelX = menu.isIntelligent() ? 89 - font.width(CRAFTING) / 2 : 28;
        int clearX = menu.isIntelligent() ? 66 : 88;
        addRenderableWidget(Button.builder(Component.literal("c"), button -> pressButton(WorkbenchBackpackMenu.BUTTON_CLEAR))
                .bounds(leftPos + clearX, topPos + 16, 11, 11)
                .tooltip(Tooltip.create(Component.translatable("tooltip.backpack.clear_craft_matrix")))
                .build());
        if (menu.isIntelligent()) {
            Component saveTooltip = Component.translatable("tooltip.backpack.save_recipe")
                    .append("\n").append(Component.translatable("tooltip.backpack.click_a_slot"));
            addRenderableWidget(Button.builder(Component.literal("s"), button -> pressButton(WorkbenchBackpackMenu.BUTTON_SAVE))
                    .bounds(leftPos + 81, topPos + 16, 11, 11)
                    .tooltip(Tooltip.create(saveTooltip))
                    .build());
        }
    }

    private void pressButton(int id) {
        if (minecraft != null && minecraft.gameMode != null) {
            minecraft.gameMode.handleInventoryButtonClick(menu.containerId, id);
        }
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (codePoint == 'c' || codePoint == 'C') {
            pressButton(WorkbenchBackpackMenu.BUTTON_CLEAR);
            return true;
        }
        if (codePoint == 's' || codePoint == 'S') {
            pressButton(WorkbenchBackpackMenu.BUTTON_SAVE);
            return true;
        }
        return super.charTyped(codePoint, modifiers);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        GuiParts.window(graphics, leftPos, topPos, imageWidth, imageHeight);
        for (Slot slot : menu.slots) {
            if (slot instanceof BackpackResultSlot) {
                GuiParts.resultSlot(graphics, leftPos + slot.x, topPos + slot.y);
            } else {
                GuiParts.slot(graphics, leftPos + slot.x, topPos + slot.y);
            }
        }
        if (!menu.isIntelligent()) {
            GuiParts.arrow(graphics, leftPos + 90, topPos + 35);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(font, CRAFTING, titleLabelX, titleLabelY, GuiParts.LABEL_COLOR, false);
        graphics.drawString(font, playerInventoryTitle, inventoryLabelX, inventoryLabelY, GuiParts.LABEL_COLOR, false);
    }
}
