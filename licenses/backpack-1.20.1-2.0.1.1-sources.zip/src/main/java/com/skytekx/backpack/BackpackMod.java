package com.skytekx.backpack;

import com.mojang.logging.LogUtils;
import com.skytekx.backpack.compat.InventorySorterCompat;
import com.skytekx.backpack.network.BackpackNetwork;
import com.skytekx.backpack.registry.ModItems;
import com.skytekx.backpack.registry.ModMenus;
import com.skytekx.backpack.registry.ModRecipes;
import com.skytekx.backpack.registry.ModTabs;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * Unofficial Forge 1.20.1 port of Backpack 2.0.1 by Eydamos for the SkyTekx3 modpack.
 */
@Mod(BackpackMod.MOD_ID)
public final class BackpackMod {
    public static final String MOD_ID = "backpack";
    public static final Logger LOGGER = LogUtils.getLogger();

    // FMLJavaModLoadingContext.get() still works on every Forge 47 build, which the
    // constructor parameter does not promise, so the deprecation is accepted here.
    @SuppressWarnings("removal")
    public BackpackMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modBus);
        ModTabs.TABS.register(modBus);
        ModRecipes.SERIALIZERS.register(modBus);
        ModMenus.MENUS.register(modBus);
        modBus.addListener(ModTabs::addToVanillaTabs);
        modBus.addListener(BackpackMod::commonSetup);
        modBus.addListener(InventorySorterCompat::enqueue);
    }

    private static void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(BackpackNetwork::register);
    }

    @SuppressWarnings("removal")
    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }
}
