package com.skytekx.backpack.storage;

import java.util.function.Predicate;
import net.minecraft.core.NonNullList;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** A plain container over a list that can grow and reports every change. */
public class ListContainer implements Container {
    private NonNullList<ItemStack> items;
    private final int maxStackSize;
    private final Predicate<ItemStack> mayPlace;
    private final Runnable onChanged;

    public ListContainer(int size, int maxStackSize, Predicate<ItemStack> mayPlace, Runnable onChanged) {
        this.items = NonNullList.withSize(size, ItemStack.EMPTY);
        this.maxStackSize = maxStackSize;
        this.mayPlace = mayPlace;
        this.onChanged = onChanged;
    }

    /** The backing list. Code that changes it directly must call {@link #setChanged()}. */
    public NonNullList<ItemStack> items() {
        return items;
    }

    /** Grows the container to at least the given size. It never shrinks, so no stack is lost. */
    public boolean ensureSize(int size) {
        if (size <= items.size()) {
            return false;
        }
        NonNullList<ItemStack> grown = NonNullList.withSize(size, ItemStack.EMPTY);
        for (int i = 0; i < items.size(); i++) {
            grown.set(i, items.get(i));
        }
        items = grown;
        setChanged();
        return true;
    }

    /** Counts the non empty stacks among the first {@code limit} slots. */
    public int countUsed(int limit) {
        int used = 0;
        for (int i = 0; i < Math.min(limit, items.size()); i++) {
            if (!items.get(i).isEmpty()) {
                used++;
            }
        }
        return used;
    }

    @Override
    public int getContainerSize() {
        return items.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return slot >= 0 && slot < items.size() ? items.get(slot) : ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack removed = ContainerHelper.removeItem(items, slot, amount);
        if (!removed.isEmpty()) {
            setChanged();
        }
        return removed;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        ItemStack removed = ContainerHelper.takeItem(items, slot);
        if (!removed.isEmpty()) {
            setChanged();
        }
        return removed;
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        if (slot < 0 || slot >= items.size()) {
            return;
        }
        items.set(slot, stack);
        if (stack.getCount() > getMaxStackSize()) {
            stack.setCount(getMaxStackSize());
        }
        setChanged();
    }

    @Override
    public int getMaxStackSize() {
        return maxStackSize;
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return mayPlace.test(stack);
    }

    @Override
    public void setChanged() {
        onChanged.run();
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    @Override
    public void clearContent() {
        items.clear();
        setChanged();
    }
}
