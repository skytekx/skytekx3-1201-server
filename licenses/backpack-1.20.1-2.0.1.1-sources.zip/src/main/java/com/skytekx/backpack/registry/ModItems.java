package com.skytekx.backpack.registry;

import com.skytekx.backpack.BackpackMod;
import com.skytekx.backpack.item.BackpackItem;
import com.skytekx.backpack.item.BackpackKind;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, BackpackMod.MOD_ID);

    /**
     * The color order of 2.0.1, which is the 1.7.10 dye metadata order. The numeric ids of
     * {@link DyeColor} run the other way, so they must not be used to map old color values.
     */
    public static final List<DyeColor> COLOR_ORDER = List.of(
            DyeColor.BLACK, DyeColor.RED, DyeColor.GREEN, DyeColor.BROWN,
            DyeColor.BLUE, DyeColor.PURPLE, DyeColor.CYAN, DyeColor.LIGHT_GRAY,
            DyeColor.GRAY, DyeColor.PINK, DyeColor.LIME, DyeColor.YELLOW,
            DyeColor.LIGHT_BLUE, DyeColor.MAGENTA, DyeColor.ORANGE, DyeColor.WHITE);

    public static final RegistryObject<BackpackItem> BACKPACK = backpack("backpack", BackpackKind.NORMAL, null);
    public static final Map<DyeColor, RegistryObject<BackpackItem>> COLORED_BACKPACKS = colored("", BackpackKind.NORMAL);
    public static final RegistryObject<BackpackItem> BIG_BACKPACK = backpack("big_backpack", BackpackKind.BIG, null);
    public static final Map<DyeColor, RegistryObject<BackpackItem>> BIG_COLORED_BACKPACKS = colored("big_", BackpackKind.BIG);
    public static final RegistryObject<BackpackItem> ENDER_BACKPACK = backpack("ender_backpack", BackpackKind.ENDER, null);
    public static final RegistryObject<BackpackItem> WORKBENCH_BACKPACK = backpack("workbench_backpack", BackpackKind.WORKBENCH, null);
    public static final RegistryObject<BackpackItem> BIG_WORKBENCH_BACKPACK = backpack("big_workbench_backpack", BackpackKind.BIG_WORKBENCH, null);

    public static final RegistryObject<Item> BOUND_LEATHER = ITEMS.register("bound_leather", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> TANNED_LEATHER = ITEMS.register("tanned_leather", () -> new Item(new Item.Properties()));

    private ModItems() {
    }

    private static RegistryObject<BackpackItem> backpack(String name, BackpackKind kind, @Nullable DyeColor color) {
        return ITEMS.register(name, () -> new BackpackItem(kind, color, new Item.Properties()));
    }

    private static Map<DyeColor, RegistryObject<BackpackItem>> colored(String prefix, BackpackKind kind) {
        Map<DyeColor, RegistryObject<BackpackItem>> map = new EnumMap<>(DyeColor.class);
        for (DyeColor color : COLOR_ORDER) {
            map.put(color, backpack(prefix + color.getName() + "_backpack", kind, color));
        }
        return Collections.unmodifiableMap(map);
    }
}
