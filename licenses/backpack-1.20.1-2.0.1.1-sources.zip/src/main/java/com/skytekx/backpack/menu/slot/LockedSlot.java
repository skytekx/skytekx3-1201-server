package com.skytekx.backpack.menu.slot;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;

/**
 * The player inventory slot that holds the open backpack. Nothing can be taken from it or put
 * into it while the backpack is open, as in Backpack 3.0.2.
 */
public class LockedSlot extends Slot {
    public LockedSlot(Container container, int index, int x, int y) {
        super(container, index, x, y);
    }

    @Override
    public boolean mayPickup(Player player) {
        return false;
    }

    @Override
    public boolean mayPlace(ItemStack stack) {
        return false;
    }

    @Override
    public boolean allowModification(Player player) {
        return false;
    }
}
