package com.skytekx.backpack.network;

import com.skytekx.backpack.item.BackpackItem;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraft.SharedConstants;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

/** Sent by the rename screen. The server renames the backpack in the given hand. */
public record RenameBackpackPacket(InteractionHand hand, String name) {
    public static final int MAX_LENGTH = 32;

    public void encode(FriendlyByteBuf buffer) {
        buffer.writeEnum(hand);
        buffer.writeUtf(name, 256);
    }

    public static RenameBackpackPacket decode(FriendlyByteBuf buffer) {
        return new RenameBackpackPacket(buffer.readEnum(InteractionHand.class), buffer.readUtf(256));
    }

    public void handle(Supplier<NetworkEvent.Context> context) {
        ServerPlayer player = context.get().getSender();
        String clean = validName(name);
        if (player != null && clean != null) {
            ItemStack stack = player.getItemInHand(hand);
            if (stack.getItem() instanceof BackpackItem item && !item.kind().isEnder()) {
                stack.setHoverName(nameComponent(clean));
            }
        }
        context.get().setPacketHandled(true);
    }

    /** Removes characters chat would refuse and trims. Returns null unless 1 to 32 characters remain. */
    @Nullable
    public static String validName(String raw) {
        String clean = SharedConstants.filterText(raw).trim();
        return clean.isEmpty() || clean.length() > MAX_LENGTH ? null : clean;
    }

    /** A custom name without the italics of an anvil name, as in 2.0.1. */
    public static Component nameComponent(String name) {
        return Component.literal(name).withStyle(style -> style.withItalic(false));
    }
}
