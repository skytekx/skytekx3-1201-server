package com.skytekx.backpack.menu;

import com.skytekx.backpack.item.BackpackKind;
import com.skytekx.backpack.menu.slot.BackpackResultSlot;
import com.skytekx.backpack.menu.slot.DisplaySlot;
import com.skytekx.backpack.menu.slot.EmptyContainer;
import com.skytekx.backpack.menu.slot.GhostSlot;
import com.skytekx.backpack.menu.slot.RecipeSlot;
import com.skytekx.backpack.registry.ModMenus;
import com.skytekx.backpack.storage.BackpackData;
import com.skytekx.backpack.storage.BackpackRules;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.NonNullList;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.inventory.ResultContainer;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.event.ForgeEventFactory;

/**
 * The menu of the two workbench backpacks: a ghost grid, a result that is crafted from the
 * backpack storage and, on intelligent backpacks, nine saved recipes.
 *
 * <p>Menu slots are the result (0), the ghost grid (1 to 9), on intelligent backpacks the recipes
 * (10 to 18), then the storage, the main inventory and the hotbar. The result, ghost and recipe
 * slots are {@link DisplaySlot}s, which keep their stacks out of the containers they expose.
 */
public class WorkbenchBackpackMenu extends AbstractBackpackMenu {
    public static final int RESULT_SLOT = 0;
    public static final int GRID_START = 1;
    public static final int GRID_END = 10;
    public static final int RECIPES_START = 10;
    public static final int RECIPES_END = 19;
    public static final int BUTTON_CLEAR = 0;
    public static final int BUTTON_SAVE = 1;
    /**
     * The most crafts of one shift click, as many as a full vanilla crafting grid allows. It keeps
     * a recipe whose output is also its input from looping forever on the server thread.
     */
    private static final int MAX_SHIFT_CRAFTS = 64;

    private final boolean intelligent;
    @Nullable
    private final BackpackData data;
    private final Container grid;
    private final Container recipeIcons;
    /** Holds the preview of the result slot and the recipe for the recipe book. No slot exposes it. */
    private final ResultContainer result = new ResultContainer();
    private int seenGridVersion = -1;
    private boolean saveMode;
    @Nullable
    private CraftPlan pendingPlan;

    public WorkbenchBackpackMenu(int containerId, Inventory playerInventory, BackpackKind kind, int lockedSlot,
                                 boolean intelligent, @Nullable UUID backpackId, @Nullable BackpackData data) {
        super(ModMenus.WORKBENCH_BACKPACK.get(), containerId, playerInventory,
                data != null ? data.storage() : new SimpleContainer(kind.storageSize()),
                kind, lockedSlot, backpackId, data != null ? data::setDirty : null);
        this.intelligent = intelligent;
        this.data = data;
        this.grid = data != null ? data.grid() : new SimpleContainer(BackpackData.GRID_SIZE);
        this.recipeIcons = data != null ? data.recipeIcons() : new SimpleContainer(BackpackData.RECIPE_COUNT);

        addSlot(new BackpackResultSlot(this, new EmptyContainer(1), result, intelligent ? 80 : 125, 35));
        int gridLeft = intelligent ? 8 : 30;
        EmptyContainer gridPlaceholder = new EmptyContainer(BackpackData.GRID_SIZE);
        for (int i = 0; i < BackpackData.GRID_SIZE; i++) {
            addSlot(new GhostSlot(gridPlaceholder, grid, i, gridLeft + 18 * (i % 3), 17 + 18 * (i / 3)));
        }
        if (intelligent) {
            EmptyContainer recipePlaceholder = new EmptyContainer(BackpackData.RECIPE_COUNT);
            for (int i = 0; i < BackpackData.RECIPE_COUNT; i++) {
                addSlot(new RecipeSlot(recipePlaceholder, recipeIcons, i, 116 + 18 * (i % 3), 17 + 18 * (i / 3)));
            }
        }
        int rows = kind.storageRows();
        addStorageSlots(8, 76);
        addPlayerSlots(90 + 18 * rows, 150 + 18 * rows);
        refreshResult();
    }

    /** Builds the client side menu from the data the server sent. */
    public static WorkbenchBackpackMenu fromNetwork(int containerId, Inventory playerInventory, @Nullable FriendlyByteBuf buffer) {
        MenuInfo info = MenuInfo.read(buffer, BackpackKind.WORKBENCH);
        return new WorkbenchBackpackMenu(containerId, playerInventory, info.kind(), info.lockedSlot(), info.intelligent(), null, null);
    }

    public boolean isIntelligent() {
        return intelligent;
    }

    private boolean isGhostSlot(int index) {
        return index >= GRID_START && index < GRID_END;
    }

    private boolean isRecipeSlot(int index) {
        return intelligent && index >= RECIPES_START && index < RECIPES_END;
    }

    /** True only while a click on the result is handled with a checked crafting plan. */
    public boolean isTakingResult() {
        return pendingPlan != null;
    }

    @Override
    public void clicked(int slotId, int button, ClickType clickType, Player player) {
        if (clickType == ClickType.SWAP && button == lockedSlot) {
            return;
        }
        if (slotId == RESULT_SLOT) {
            clickResult(button, clickType, player);
        } else if (isGhostSlot(slotId)) {
            clickGhost(slotId, button, clickType, player);
        } else if (isRecipeSlot(slotId)) {
            clickRecipe(slotId - RECIPES_START, clickType);
        } else {
            super.clicked(slotId, button, clickType, player);
        }
    }

    private void clickResult(int button, ClickType clickType, Player player) {
        switch (clickType) {
            case QUICK_MOVE -> {
                if (!player.level().isClientSide) {
                    shiftCraft(player);
                }
            }
            case PICKUP, THROW, SWAP -> {
                // The client waits for the server, which alone knows the storage contents.
                if (player.level().isClientSide) {
                    return;
                }
                CraftPlan plan = planCraft(player);
                result.setItem(0, plan != null ? plan.result().copy() : ItemStack.EMPTY);
                pendingPlan = plan;
                try {
                    super.clicked(RESULT_SLOT, button, clickType, player);
                } finally {
                    pendingPlan = null;
                    refreshResult();
                }
            }
            default -> super.clicked(RESULT_SLOT, button, clickType, player);
        }
    }

    /**
     * A left or right click puts a copy of the cursor stack with a count of 1 into the ghost
     * slot, or clears it when the cursor is empty. A middle click clears it. The cursor stack
     * is never used up.
     */
    private void clickGhost(int slotId, int button, ClickType clickType, Player player) {
        Slot slot = slots.get(slotId);
        switch (clickType) {
            case PICKUP -> {
                ItemStack carried = getCarried();
                slot.set(carried.isEmpty() ? ItemStack.EMPTY : carried.copyWithCount(1));
            }
            case CLONE -> slot.set(ItemStack.EMPTY);
            case QUICK_CRAFT -> super.clicked(slotId, button, clickType, player);
            default -> {
            }
        }
    }

    /**
     * In save mode a click stores the current result and ghost grid under the recipe slot.
     * Otherwise it loads the saved ghost grid, an empty recipe clears the grid.
     */
    private void clickRecipe(int index, ClickType clickType) {
        if (data == null || (clickType != ClickType.PICKUP && clickType != ClickType.QUICK_MOVE && clickType != ClickType.CLONE)) {
            return;
        }
        if (saveMode) {
            saveMode = false;
            ItemStack shown = result.getItem(0);
            if (!shown.isEmpty()) {
                data.saveRecipe(index, shown);
            }
        } else {
            data.loadRecipe(index);
        }
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (id == BUTTON_CLEAR) {
            if (data != null) {
                data.clearGrid();
            }
            return true;
        }
        if (id == BUTTON_SAVE) {
            if (intelligent && !result.getItem(0).isEmpty()) {
                saveMode = true;
            }
            return true;
        }
        return false;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        if (index == RESULT_SLOT || isGhostSlot(index) || isRecipeSlot(index)) {
            return ItemStack.EMPTY;
        }
        return super.quickMoveStack(player, index);
    }

    @Override
    public boolean canTakeItemForPickAll(ItemStack stack, Slot slot) {
        return !(slot instanceof DisplaySlot);
    }

    @Override
    public boolean canDragTo(Slot slot) {
        return !(slot instanceof DisplaySlot);
    }

    @Override
    public void broadcastChanges() {
        if (data != null && data.gridVersion() != seenGridVersion) {
            refreshResult();
        }
        super.broadcastChanges();
    }

    /** Shows the output of the ghost grid in the result slot, on the server. */
    private void refreshResult() {
        if (data == null || !(player instanceof ServerPlayer serverPlayer)) {
            return;
        }
        seenGridVersion = data.gridVersion();
        Level level = player.level();
        CraftingContainer ghosts = craftingGrid(ghostStacks());
        ItemStack shown = ItemStack.EMPTY;
        Optional<CraftingRecipe> recipe = level.getRecipeManager().getRecipeFor(RecipeType.CRAFTING, ghosts, level);
        if (recipe.isPresent() && result.setRecipeUsed(level, serverPlayer, recipe.get())) {
            ItemStack output = recipe.get().assemble(ghosts, level.registryAccess());
            if (output.isItemEnabled(level.enabledFeatures())) {
                shown = output;
            }
        }
        result.setItem(0, shown);
    }

    private NonNullList<ItemStack> ghostStacks() {
        NonNullList<ItemStack> stacks = NonNullList.withSize(BackpackData.GRID_SIZE, ItemStack.EMPTY);
        for (int i = 0; i < BackpackData.GRID_SIZE; i++) {
            ItemStack ghost = grid.getItem(i);
            stacks.set(i, ghost.isEmpty() ? ItemStack.EMPTY : ghost.copyWithCount(1));
        }
        return stacks;
    }

    private CraftingContainer craftingGrid(NonNullList<ItemStack> stacks) {
        return new TransientCraftingContainer(this, 3, 3, stacks);
    }

    /**
     * Finds storage stacks for every ghost stack and the output they craft. Exactly equal stacks
     * are taken first, then any stack the recipe accepts in that position, which stands in for
     * the ore dictionary matching of 2.0.1. Returns null when the storage lacks an ingredient.
     */
    @Nullable
    private CraftPlan planCraft(Player player) {
        if (data == null || !(player instanceof ServerPlayer serverPlayer)) {
            return null;
        }
        Level level = player.level();
        NonNullList<ItemStack> ghosts = ghostStacks();
        Optional<CraftingRecipe> found = level.getRecipeManager().getRecipeFor(RecipeType.CRAFTING, craftingGrid(ghosts), level);
        if (found.isEmpty()) {
            return null;
        }
        CraftingRecipe recipe = found.get();
        int size = kind.storageSize();
        int[] left = new int[size];
        for (int s = 0; s < size; s++) {
            left[s] = storage.getItem(s).getCount();
        }
        int[] sources = new int[BackpackData.GRID_SIZE];
        NonNullList<ItemStack> real = NonNullList.withSize(BackpackData.GRID_SIZE, ItemStack.EMPTY);
        for (int g = 0; g < BackpackData.GRID_SIZE; g++) {
            sources[g] = -1;
            if (ghosts.get(g).isEmpty()) {
                continue;
            }
            for (int s = 0; s < size; s++) {
                ItemStack stack = storage.getItem(s);
                if (left[s] > 0 && ItemStack.isSameItemSameTags(stack, ghosts.get(g))) {
                    sources[g] = s;
                    left[s]--;
                    real.set(g, stack.copyWithCount(1));
                    break;
                }
            }
        }
        for (int g = 0; g < BackpackData.GRID_SIZE; g++) {
            if (ghosts.get(g).isEmpty() || sources[g] >= 0) {
                continue;
            }
            for (int s = 0; s < size && sources[g] < 0; s++) {
                ItemStack stack = storage.getItem(s);
                if (left[s] <= 0 || stack.isEmpty()) {
                    continue;
                }
                NonNullList<ItemStack> trial = NonNullList.withSize(BackpackData.GRID_SIZE, ItemStack.EMPTY);
                for (int k = 0; k < BackpackData.GRID_SIZE; k++) {
                    trial.set(k, sources[k] >= 0 ? real.get(k) : ghosts.get(k));
                }
                trial.set(g, stack.copyWithCount(1));
                if (recipe.matches(craftingGrid(trial), level)) {
                    sources[g] = s;
                    left[s]--;
                    real.set(g, stack.copyWithCount(1));
                }
            }
            if (sources[g] < 0) {
                return null;
            }
        }
        CraftingContainer realGrid = craftingGrid(real);
        if (!recipe.matches(realGrid, level) || !result.setRecipeUsed(level, serverPlayer, recipe)) {
            return null;
        }
        ItemStack output = recipe.assemble(realGrid, level.registryAccess());
        if (output.isEmpty() || !output.isItemEnabled(level.enabledFeatures())) {
            return null;
        }
        return new CraftPlan(recipe, output, sources, realGrid);
    }

    /** Called by the result slot after the player took the crafted stack. */
    public void onResultTaken(Player player, ItemStack taken) {
        CraftPlan plan = pendingPlan;
        if (plan == null || taken.isEmpty()) {
            return;
        }
        pendingPlan = null;
        finishCraft(player, plan, taken);
    }

    /** Fires the crafting events and uses up the ingredients of the plan in the storage. */
    private void finishCraft(Player player, CraftPlan plan, ItemStack crafted) {
        crafted.onCraftedBy(player.level(), player, crafted.getCount());
        ForgeEventFactory.firePlayerCraftingEvent(player, crafted, plan.grid());
        result.setRecipeUsed(plan.recipe());
        result.awardUsedRecipes(player, plan.grid().getItems());
        ForgeHooks.setCraftingPlayer(player);
        NonNullList<ItemStack> remainders = plan.recipe().getRemainingItems(plan.grid());
        ForgeHooks.setCraftingPlayer(null);
        for (int g = 0; g < BackpackData.GRID_SIZE; g++) {
            int source = plan.sources()[g];
            if (source < 0) {
                continue;
            }
            storage.removeItem(source, 1);
            ItemStack remainder = g < remainders.size() ? remainders.get(g) : ItemStack.EMPTY;
            if (!remainder.isEmpty()) {
                giveRemainder(player, source, remainder.copy());
            }
        }
    }

    /**
     * Puts a container item such as an empty bucket into the slot its ingredient came from when
     * that slot is empty now, else into the storage, else into the player inventory, else onto
     * the ground.
     */
    private void giveRemainder(Player player, int source, ItemStack remainder) {
        if (storage.getItem(source).isEmpty() && BackpackRules.mayStore(remainder)) {
            storage.setItem(source, remainder);
            return;
        }
        moveItemStackTo(remainder, storageStart, storageEnd, false);
        if (!remainder.isEmpty() && !player.getInventory().add(remainder)) {
            player.drop(remainder, false);
        }
    }

    /**
     * Shift click on the result crafts again and again, at most {@link #MAX_SHIFT_CRAFTS} times,
     * while the storage holds the ingredients, the result stays the same item and the whole
     * crafted stack fits. It goes into the storage first, then the hotbar from the right, then the
     * main inventory.
     */
    private void shiftCraft(Player player) {
        ItemStack first = ItemStack.EMPTY;
        for (int i = 0; i < MAX_SHIFT_CRAFTS; i++) {
            CraftPlan plan = planCraft(player);
            if (plan == null) {
                break;
            }
            ItemStack crafted = plan.result().copy();
            if (!first.isEmpty() && !ItemStack.isSameItem(first, crafted)) {
                break;
            }
            int room = roomFor(crafted, storageStart, storageEnd) + roomFor(crafted, hotbarStart, hotbarEnd)
                    + roomFor(crafted, inventoryStart, inventoryEnd);
            if (room < crafted.getCount()) {
                break;
            }
            if (first.isEmpty()) {
                first = crafted.copy();
            }
            finishCraft(player, plan, crafted);
            moveItemStackTo(crafted, storageStart, storageEnd, false);
            moveItemStackTo(crafted, hotbarStart, hotbarEnd, true);
            moveItemStackTo(crafted, inventoryStart, inventoryEnd, false);
            if (!crafted.isEmpty()) {
                player.drop(crafted, false);
            }
        }
        refreshResult();
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        saveMode = false;
    }

    private record CraftPlan(CraftingRecipe recipe, ItemStack result, int[] sources, CraftingContainer grid) {
    }
}
