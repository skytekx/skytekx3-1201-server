package com.skytekx.backpack.compat;

import com.skytekx.backpack.menu.slot.BackpackResultSlot;
import com.skytekx.backpack.menu.slot.GhostSlot;
import com.skytekx.backpack.menu.slot.LockedSlot;
import com.skytekx.backpack.menu.slot.RecipeSlot;
import java.util.List;
import net.minecraftforge.fml.InterModComms;
import net.minecraftforge.fml.event.lifecycle.InterModEnqueueEvent;

/**
 * Keeps Inventory Sorter, which is part of SkyTekx3, away from slots that hold no real items or
 * must not change: the ghost grid, the saved recipes, the crafting result and the held backpack.
 * Nothing happens when Inventory Sorter is missing.
 */
public final class InventorySorterCompat {
    private static final String MOD_ID = "inventorysorter";

    private InventorySorterCompat() {
    }

    public static void enqueue(InterModEnqueueEvent event) {
        for (Class<?> slotClass : List.of(GhostSlot.class, RecipeSlot.class, BackpackResultSlot.class, LockedSlot.class)) {
            String name = slotClass.getName();
            InterModComms.sendTo(MOD_ID, "slotblacklist", () -> name);
        }
    }
}
