See AGENTS.md.
