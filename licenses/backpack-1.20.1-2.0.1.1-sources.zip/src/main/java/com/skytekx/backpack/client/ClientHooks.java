package com.skytekx.backpack.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.world.InteractionHand;

/**
 * Entry points from common code into the client. Common code reaches them only through
 * {@code DistExecutor}, so a dedicated server never loads this class.
 */
public final class ClientHooks {
    private ClientHooks() {
    }

    public static void openRenameScreen(InteractionHand hand) {
        Minecraft.getInstance().setScreen(new RenameScreen(hand));
    }

    public static boolean hasShiftDown() {
        return Screen.hasShiftDown();
    }
}
