package com.skytekx.backpack.menu;

import com.skytekx.backpack.item.BackpackKind;
import com.skytekx.backpack.registry.ModMenus;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;

/** The menu of the normal, big and ender backpacks, laid out as in 2.0.1. */
public class BackpackMenu extends AbstractBackpackMenu {
    public BackpackMenu(int containerId, Inventory playerInventory, Container storage, BackpackKind kind,
                        int lockedSlot, @Nullable UUID backpackId, @Nullable Runnable onStorageChanged) {
        super(ModMenus.BACKPACK.get(), containerId, playerInventory, storage, kind, lockedSlot, backpackId, onStorageChanged);
        int rows = kind.storageRows();
        addStorageSlots(8, 17);
        addPlayerSlots(31 + 18 * rows, 91 + 18 * rows);
    }

    /** Builds the client side menu from the data the server sent. */
    public static BackpackMenu fromNetwork(int containerId, Inventory playerInventory, @Nullable FriendlyByteBuf buffer) {
        MenuInfo info = MenuInfo.read(buffer, BackpackKind.NORMAL);
        return new BackpackMenu(containerId, playerInventory, new SimpleContainer(info.kind().storageSize()), info.kind(),
                info.lockedSlot(), null, null);
    }
}
