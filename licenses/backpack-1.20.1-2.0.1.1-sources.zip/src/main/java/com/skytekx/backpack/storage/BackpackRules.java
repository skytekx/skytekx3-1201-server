package com.skytekx.backpack.storage;

import com.skytekx.backpack.item.BackpackItem;
import com.skytekx.backpack.registry.ModTags;
import net.minecraft.world.item.ItemStack;

public final class BackpackRules {
    private BackpackRules() {
    }

    /**
     * Whether a stack may go into backpack storage. Backpacks never may, as in 2.0.1, and the
     * tag {@code backpack:not_allowed_in_backpacks} takes the place of the disallowItems setting.
     */
    public static boolean mayStore(ItemStack stack) {
        return !(stack.getItem() instanceof BackpackItem) && !stack.is(ModTags.NOT_ALLOWED_IN_BACKPACKS);
    }
}
