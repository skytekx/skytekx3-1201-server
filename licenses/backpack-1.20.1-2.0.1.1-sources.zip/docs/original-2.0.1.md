# Backpack 2.0.1 for Minecraft 1.7.10: port reference

This document describes the Minecraft mod Backpack by Eydamos, version 2.0.1 for Minecraft 1.7.10, closely enough to port it to Forge 1.20.1 without the original jar. It was written from a ForgeFlower decompile of `backpack-2.0.1-1.7.x.jar`. The decompiled code uses SRG names such as `func_77659_a`. This document uses the readable MCP names of that era instead, such as `onItemRightClick`. Version 3.0.2 for Minecraft 1.12.2 was consulted only where 2.0.1 leaves a question open, and those places say so. Version 3.0.2 is a different design, with leather tiers, frames, sizes and module slots stored on the item.

The port targets the SkyTekx3 modpack (Forge 1.20.1, Forge 47.4.6, Java 17) under the mod id `backpack`. In scope are bound leather, tanned leather, the undyed backpack and its 16 colors, the big backpacks, the two workbench backpacks and the ender backpack, all with the original textures. Out of scope for now are the personal backpack slot, the key binding (B by default), the automatic pickup filter that belongs to the personal slot and the backpack model on the player. Section 11 still describes them so that nothing is lost.

Coordinates in GUI sections are relative to the top left corner of the GUI window. A slot position is where its 16 by 16 item is drawn, as in vanilla. The slot background starts one pixel above and left of it.

## Contents

1. Source, license and credits
2. Items
3. Slot counts and the ender backpack
4. Recipes
5. Storage
6. Opening, protection and renaming
7. Workbench backpack
8. GUI layouts and guiCombined.png
9. Language files
10. Configuration
11. Out of scope features
12. Lifecycle, event handlers and network messages
13. Known defects in 2.0.1
14. Port notes

## 1. Source, license and credits

| Field | Value |
|---|---|
| Mod id in 1.7.10 | `Backpack` |
| Version | 2.0.1 (`mcmod.info` says `2.0.1-1.7.x`) |
| Minecraft | 1.7.x, built against Forge for 1.7.10 |
| Author | Eydamos |
| Credits, verbatim from `mcmod.info` | `(Backpacks *-1.2.5)MightyPork, (Icons)Simsala123 and SentientXIII, (Model)Ivanovsky` |
| Description, verbatim | `Provides the player with multiple, colored backpacks, which each has the space of a normal chest.` |
| URL in `mcmod.info` | `http://www.minecraftforum.net/topic/1492661-` |
| License | LGPL-2.1 according to the CurseForge page. The jar contains no license file. |

The jar holds two code packages. Package `de.eydamos.backpack` is the mod itself. Package `de.eydamos.guiadvanced` is a small GUI helper library by the same author that draws window frames, slots, labels, buttons and a text box. The assets are two language files, 39 item textures, one GUI texture sheet and one player model texture.

Optional integrations in 2.0.1 are NEI (a recipe overlay handler, registered by reflection), Inventory Tweaks (the annotations `@ChestContainer` and `@ContainerSectionCallback` on the containers) and the VersionChecker mod (an IMC message that points at `http://www.eydamos.de/minecraft/backpack/version.json`).

## 2. Items

### 2.1 Registered items and the damage scheme

Four items are registered with `GameRegistry.registerItem`, so their 1.7.10 names carry the mod id `Backpack`.

| 1.7.10 name | Class | Unlocalized name | Max stack | Creative tab |
|---|---|---|---|---|
| `Backpack:backpack` | `ItemBackpack` | `item.backpack` | 1 | Backpacks |
| `Backpack:workbenchbackpack` | `ItemWorkbenchBackpack` | `item.workbenchbackpack` | 1 | Backpacks |
| `Backpack:boundLeather` | `ItemLeather` | `item.boundLeather` | 64 | Materials (vanilla) |
| `Backpack:tannedLeather` | `ItemLeather` | `item.tannedLeather` | 64 | Materials (vanilla) |

The two backpack items use the damage value as metadata, built as `tier * 100 + color`.

- The tier is `damage / 100` when that is below 3, otherwise 0. Tier 0 is the normal backpack, tier 1 is a dead "medium" tier (see 2.5) and tier 2 is the big backpack.
- The color is `damage % 100`. Value 0 is undyed, values 1 to 16 are the colors of the table in 2.2, value 17 marks the workbench backpack and value 99 the ender backpack.
- The ender backpack is the single value 31999 on `Backpack:backpack`. Its tier computes to 0 and its color to 99.
- The workbench backpack exists as damage 17 (small) and 217 (big) on `Backpack:workbenchbackpack`.
- The leathers have no subtypes and are always damage 0.

### 2.2 Colors

The color order of 2.0.1 is the 1.7.10 dye metadata order plus one. The same order is used for the damage values, the textures, the ore dictionary dye names and the creative tab.

| Color value | 2.0.1 name | Ore dictionary name | 1.7.10 vanilla dye (`minecraft:dye` metadata) | Forge 1.20.1 tag | 1.20.1 `DyeColor` |
|---|---|---|---|---|---|
| 1 | `black` | `dyeBlack` | Ink sac (0) | `forge:dyes/black` | `BLACK` |
| 2 | `red` | `dyeRed` | Rose red (1) | `forge:dyes/red` | `RED` |
| 3 | `green` | `dyeGreen` | Cactus green (2) | `forge:dyes/green` | `GREEN` |
| 4 | `brown` | `dyeBrown` | Cocoa beans (3) | `forge:dyes/brown` | `BROWN` |
| 5 | `blue` | `dyeBlue` | Lapis lazuli (4) | `forge:dyes/blue` | `BLUE` |
| 6 | `purple` | `dyePurple` | Purple dye (5) | `forge:dyes/purple` | `PURPLE` |
| 7 | `cyan` | `dyeCyan` | Cyan dye (6) | `forge:dyes/cyan` | `CYAN` |
| 8 | `lightGray` | `dyeLightGray` | Light gray dye (7) | `forge:dyes/light_gray` | `LIGHT_GRAY` |
| 9 | `gray` | `dyeGray` | Gray dye (8) | `forge:dyes/gray` | `GRAY` |
| 10 | `pink` | `dyePink` | Pink dye (9) | `forge:dyes/pink` | `PINK` |
| 11 | `lime` | `dyeLime` | Lime dye (10) | `forge:dyes/lime` | `LIME` |
| 12 | `yellow` | `dyeYellow` | Dandelion yellow (11) | `forge:dyes/yellow` | `YELLOW` |
| 13 | `lightBlue` | `dyeLightBlue` | Light blue dye (12) | `forge:dyes/light_blue` | `LIGHT_BLUE` |
| 14 | `magenta` | `dyeMagenta` | Magenta dye (13) | `forge:dyes/magenta` | `MAGENTA` |
| 15 | `orange` | `dyeOrange` | Orange dye (14) | `forge:dyes/orange` | `ORANGE` |
| 16 | `white` | `dyeWhite` | Bone meal (15) | `forge:dyes/white` | `WHITE` |

The numeric ids of the 1.20.1 `DyeColor` enum run the other way (white is 0, black is 15), so the old color value must not be mapped through `DyeColor.byId`. Since Minecraft 1.14 the ink sac, cocoa beans, lapis lazuli and bone meal are no longer dyes. The Forge tags `forge:dyes/<color>` in Forge 47.4.6 contain only the vanilla dye items (`minecraft:black_dye` and so on).

### 2.3 Item table

This is every item and metadata value that 2.0.1 makes usable. The proposed 1.20.1 ids follow the vanilla pattern of color first (as in `black_shulker_box`) and put the size in front. The textures are in `assets/backpack/textures/items/` in the jar. In 1.20.1 they have to be renamed, because resource paths must be lowercase. The plan is to copy each texture to `assets/backpack/textures/item/<id path>.png`, for example `backpack_lightBlue_big.png` to `big_light_blue_backpack.png`.

| 1.7.10 item | Damage | 1.7.10 lang key | English | German | Proposed 1.20.1 id | Texture in the jar |
|---|---|---|---|---|---|---|
| `Backpack:backpack` | 0 | `item.backpack.name` | Backpack | Rucksack | `backpack:backpack` | `backpack.png` |
| `Backpack:backpack` | 1 | `item.backpack.black.name` | Black Backpack | Schwarzer Rucksack | `backpack:black_backpack` | `backpack_black.png` |
| `Backpack:backpack` | 2 | `item.backpack.red.name` | Red Backpack | Roter Rucksack | `backpack:red_backpack` | `backpack_red.png` |
| `Backpack:backpack` | 3 | `item.backpack.green.name` | Green Backpack | Grüner Rucksack | `backpack:green_backpack` | `backpack_green.png` |
| `Backpack:backpack` | 4 | `item.backpack.brown.name` | Brown Backpack | Brauner Rucksack | `backpack:brown_backpack` | `backpack_brown.png` |
| `Backpack:backpack` | 5 | `item.backpack.blue.name` | Blue Backpack | Blauer Rucksack | `backpack:blue_backpack` | `backpack_blue.png` |
| `Backpack:backpack` | 6 | `item.backpack.purple.name` | Purple Backpack | Lila Rucksack | `backpack:purple_backpack` | `backpack_purple.png` |
| `Backpack:backpack` | 7 | `item.backpack.cyan.name` | Cyan Backpack | Cyan Rucksack | `backpack:cyan_backpack` | `backpack_cyan.png` |
| `Backpack:backpack` | 8 | `item.backpack.lightGray.name` | Light Gray Backpack | Hell grauer Rucksack | `backpack:light_gray_backpack` | `backpack_lightGray.png` |
| `Backpack:backpack` | 9 | `item.backpack.gray.name` | Gray Backpack | Grauer Rucksack | `backpack:gray_backpack` | `backpack_gray.png` |
| `Backpack:backpack` | 10 | `item.backpack.pink.name` | Pink Backpack | Pinker Rucksack | `backpack:pink_backpack` | `backpack_pink.png` |
| `Backpack:backpack` | 11 | `item.backpack.lime.name` | Lime Backpack | Hell grüner Rucksack | `backpack:lime_backpack` | `backpack_lime.png` |
| `Backpack:backpack` | 12 | `item.backpack.yellow.name` | Yellow Backpack | Gelber Rucksack | `backpack:yellow_backpack` | `backpack_yellow.png` |
| `Backpack:backpack` | 13 | `item.backpack.lightBlue.name` | Light Blue Backpack | Hell blauer Rucksack | `backpack:light_blue_backpack` | `backpack_lightBlue.png` |
| `Backpack:backpack` | 14 | `item.backpack.magenta.name` | Magenta Backpack | Magenta Rucksack | `backpack:magenta_backpack` | `backpack_magenta.png` |
| `Backpack:backpack` | 15 | `item.backpack.orange.name` | Orange Backpack | Oranger Rucksack | `backpack:orange_backpack` | `backpack_orange.png` |
| `Backpack:backpack` | 16 | `item.backpack.white.name` | White Backpack | Weißer Rucksack | `backpack:white_backpack` | `backpack_white.png` |
| `Backpack:backpack` | 200 | `item.backpack.big.name` | Big Backpack | Großer Rucksack | `backpack:big_backpack` | `backpack_big.png` |
| `Backpack:backpack` | 201 | `item.backpack.big_black.name` | Big Black Backpack | Großer schwarzer Rucksack | `backpack:big_black_backpack` | `backpack_black_big.png` |
| `Backpack:backpack` | 202 | `item.backpack.big_red.name` | Big Red Backpack | Großer roter Rucksack | `backpack:big_red_backpack` | `backpack_red_big.png` |
| `Backpack:backpack` | 203 | `item.backpack.big_green.name` | Big Green Backpack | Großer grüner Rucksack | `backpack:big_green_backpack` | `backpack_green_big.png` |
| `Backpack:backpack` | 204 | `item.backpack.big_brown.name` | Big Brown Backpack | Großer brauner Rucksack | `backpack:big_brown_backpack` | `backpack_brown_big.png` |
| `Backpack:backpack` | 205 | `item.backpack.big_blue.name` | Big Blue Backpack | Großer blauer Rucksack | `backpack:big_blue_backpack` | `backpack_blue_big.png` |
| `Backpack:backpack` | 206 | `item.backpack.big_purple.name` | Big Purple Backpack | Großer lila Rucksack | `backpack:big_purple_backpack` | `backpack_purple_big.png` |
| `Backpack:backpack` | 207 | `item.backpack.big_cyan.name` | Big Cyan Backpack | Großer cyan Rucksack | `backpack:big_cyan_backpack` | `backpack_cyan_big.png` |
| `Backpack:backpack` | 208 | `item.backpack.big_lightGray.name` | Big Light Gray Backpack | Großer hell grauer Rucksack | `backpack:big_light_gray_backpack` | `backpack_lightGray_big.png` |
| `Backpack:backpack` | 209 | `item.backpack.big_gray.name` | Big Gray Backpack | Großer grauer Rucksack | `backpack:big_gray_backpack` | `backpack_gray_big.png` |
| `Backpack:backpack` | 210 | `item.backpack.big_pink.name` | Big Pink Backpack | Großer pinker Rucksack | `backpack:big_pink_backpack` | `backpack_pink_big.png` |
| `Backpack:backpack` | 211 | `item.backpack.big_lime.name` | Big Lime Backpack | Großer hell grüner Rucksack | `backpack:big_lime_backpack` | `backpack_lime_big.png` |
| `Backpack:backpack` | 212 | `item.backpack.big_yellow.name` | Big Yellow Backpack | Großer gelber Rucksack | `backpack:big_yellow_backpack` | `backpack_yellow_big.png` |
| `Backpack:backpack` | 213 | `item.backpack.big_lightBlue.name` | Big Light Blue Backpack | Großer hell blauer Rucksack | `backpack:big_light_blue_backpack` | `backpack_lightBlue_big.png` |
| `Backpack:backpack` | 214 | `item.backpack.big_magenta.name` | Big Magenta Backpack | Großer magenta Rucksack | `backpack:big_magenta_backpack` | `backpack_magenta_big.png` |
| `Backpack:backpack` | 215 | `item.backpack.big_orange.name` | Big Orange Backpack | Großer oranger Rucksack | `backpack:big_orange_backpack` | `backpack_orange_big.png` |
| `Backpack:backpack` | 216 | `item.backpack.big_white.name` | Big White Backpack | Großer weißer Rucksack | `backpack:big_white_backpack` | `backpack_white_big.png` |
| `Backpack:backpack` | 31999 | `item.backpack.ender.name` | Ender Backpack | Ender Rucksack | `backpack:ender_backpack` | `backpack_ender.png` |
| `Backpack:workbenchbackpack` | 17 | `item.workbenchbackpack.name` | Workbench Backpack | Werkbank Rucksack | `backpack:workbench_backpack` | `backpack_workbench.png` |
| `Backpack:workbenchbackpack` | 217 | `item.workbenchbackpack.big.name` | Big Workbench Backpack | Großer Werkbank Rucksack | `backpack:big_workbench_backpack` | `backpack_workbench_big.png` |
| `Backpack:boundLeather` | 0 | `item.boundLeather.name` | Bound Leather | Gebundenes Leder | `backpack:bound_leather` | `leatherBound.png` |
| `Backpack:tannedLeather` | 0 | `item.tannedLeather.name` | Tanned Leather | Gegerbtes Leder | `backpack:tanned_leather` | `leatherTanned.png` |

All 39 item textures in the jar are covered by this table, and every one is 16 by 16 pixels, 8 bit RGBA. Some of them carry Adobe ImageReady text chunks, which are harmless. The jar has no textures for the medium tier.

### 2.4 Behavior shared by the backpack items

- Max stack size 1, has subtypes, `isBookEnchantable` returns false.
- The method `onItemUse` returns false. A right click on a block without its own interaction therefore falls through to `onItemRightClick` and opens the backpack (section 6.1).
- The display name is the item NBT string `customName` when present, otherwise the translation of `getUnlocalizedName(stack) + ".name"`. In 1.7.10 an anvil name (`display.Name`) still overrides the item name, but it does not change the GUI title.
- The unlocalized name is built from the base name, `item.backpack` or `item.workbenchbackpack`. A non zero tier appends `.` and the tier word (`medium` or `big`). A color value from 1 to 16 appends the color name, joined with `.` on tier 0 and with `_` on other tiers. Color value 99 appends `ender` the same way. Examples are `item.backpack`, `item.backpack.black`, `item.backpack.big`, `item.backpack.big_black`, `item.backpack.ender`, `item.workbenchbackpack` and `item.workbenchbackpack.big`.
- Icons are looked up by damage. Tier 0 and tier 2 with color 0 to 16 use `backpack[_<color>][_big]`, every damage of 300 and above uses `backpack_ender`, and the workbench item uses `backpack_workbench_big` for 217 and `backpack_workbench` for anything else.

The tooltip is built on the client.

- Without Shift it is the single line `Press SHIFT for more information` (`tooltip.more_information`).
- With left or right Shift held, every backpack except the ender backpack shows a yellow line `Tier: N` where N is `damage / 100 + 1`. That is 1 for the normal and the small workbench backpack and 3 for the big ones, because the medium tier would be 2. A second line reads `<used>/<size> Slots used`.
- Workbench backpacks add the line `Intelligent` after that when the backpack is intelligent, with or without Shift.
- The ender backpack shows nothing with Shift held.

Section 13 explains why the slot line always shows `0/0` and the `Intelligent` line never shows in 2.0.1.

The leathers (`ItemLeather`) have no tooltip, stack to 64 and sit in the vanilla Materials tab. Their icons are `leatherBound` and `leatherTanned`.

### 2.5 Creative tab and the dead medium tier

The custom tab is `tab.backpacks`, shown as `Backpacks` through the key `itemGroup.tab.backpacks`, with the undyed backpack as icon. It lists, in this order, damage 0 to 16, damage 100 to 116, damage 200 to 216, damage 31999 of `Backpack:backpack` and then damage 17 and 217 of `Backpack:workbenchbackpack`.

Damage 100 to 116 is the medium tier. It is a leftover. It has language entries (`Middle Backpack` and so on), but no textures (its icons are never registered), no recipe and a size of 0, because the size switch in `BackpackSave.initialize` has no case for tier 1. The port drops it.

## 3. Slot counts and the ender backpack

| Kind | Damage | Storage slots | Rows | Where the size comes from |
|---|---|---|---|---|
| Backpack, undyed and 16 colors | 0 to 16 | 27 | 3 | Config `backpackSlotsS`, default 27, accepted 1 to 128 |
| Big backpack, undyed and 16 colors | 200 to 216 | 54 | 6 | Config `backpackSlotsL`, default 54, accepted 1 to 128 |
| Workbench backpack | 17 | 9, plus a 3 by 3 ghost crafting grid and a result slot | 1 | Fixed |
| Big workbench backpack | 217 | 18, plus the same grid and result slot | 2 | Fixed |
| Ender backpack | 31999 | 27 | 3 | The player's vanilla ender chest inventory |
| Medium tier (dead) | 100 to 116 | 0 | 0 | No case in the code |

The size is stored in the backpack's save file when the backpack is initialized (section 5.5). A changed config value therefore only reaches an existing backpack when it passes through a crafting output again, for example through the upgrade or a recolor.

The ender backpack opens the player's own vanilla ender chest inventory (`EntityPlayer.getInventoryEnderChest()`, an `InventoryEnderChest` of 27 slots). That is the same inventory every ender chest block shows to this player. The ender backpack has no storage of its own. It still receives a UUID and a save file on first use. That file holds no items. Only its `type` and `slotsPerRow` values are used, to pick and lay out the GUI. Its GUI is the normal backpack GUI with 27 slots and the title `container.enderchest` (Ender Chest), and its container is always valid (section 6.3). Sneak and right click does nothing with it, so it cannot be renamed.

## 4. Recipes

All recipes are registered during `FMLInitializationEvent`. Recipes whose keys are plain items are vanilla `ShapedRecipes` and match exact items. The colored recipes are `ShapedOreRecipe` and accept anything registered under the ore dictionary dye name. Every output has a count of 1. The shaped recipes produce items without NBT, and new backpacks are initialized when they are taken from the output slot (section 5.5).

### 4.1 Shaped recipes

| Output | Pattern | Keys | Registered when |
|---|---|---|---|
| Backpack (0) | `LLL`, `L L`, `LLL` | L leather | `disableBackpacks` false and `airshipModCompatibility` false |
| Backpack (0), airship variant | `LLL`, `LCL`, `LLL` | L leather, C vanilla chest | `disableBackpacks` false and `airshipModCompatibility` true, replaces the recipe above |
| Colored backpack (1 to 16) | `LLL`, `LDL`, `LLL` | L leather, D ore dictionary dye of that color | `disableBackpacks` false |
| Big backpack (200) | `LLL`, `L L`, `LLL` | L tanned leather | `disableBigBackpacks` false and `bigByUpgradeOnly` false |
| Big colored backpack (201 to 216) | `LLL`, `LDL`, `LLL` | L tanned leather, D ore dictionary dye of that color | `disableBigBackpacks` false and `bigByUpgradeOnly` false |
| Ender backpack (31999) | `LLL`, `LEL`, `LLL` | L leather, E ender chest | `disableEnderBackpack` false and `enderRecipe` 0 (default) |
| Ender backpack (31999), variant | `LLL`, `LDL`, `LLL` | L leather, D eye of ender | `disableEnderBackpack` false and `enderRecipe` 1 |
| Workbench backpack (17) | `LLL`, `LWL`, `LLL` | L leather, W crafting table | `disableWorkbenchBackpack` false |
| Big workbench backpack (217) | `LLL`, `LWL`, `LLL` | L tanned leather, W crafting table | `disableWorkbenchBackpack` false |
| Bound leather | `SSS`, `LSL`, `SSS` | S string, L leather | Always |

The big workbench backpack recipe ignores `disableBigBackpacks` and `bigByUpgradeOnly`. Bound leather costs 7 string and 2 leather. A big backpack therefore costs 16 leather and 56 string plus the smelting.

### 4.2 Smelting

Bound leather smelts into one tanned leather in the furnace and gives 0.1 experience. It is registered with `GameRegistry.addSmelting(boundLeather, tannedLeatherStack, 0.1F)`, which accepts any damage of the input. The 1.7.10 furnace takes 200 ticks.

### 4.3 Upgrade to a big backpack (`RecipeEnhanceBackpack`)

```
T T T
T B T
T T T
```

T is tanned leather and B is any tier 0 backpack item, which means the undyed or a colored normal backpack or the small workbench backpack. The ender backpack is refused because 31999 / 100 is not 0.

- The recipe only matches in a 3 by 3 grid with all nine slots filled. The center (slot index 4) must be an `ItemBackpackBase` with `damage / 100 == 0`, and every other slot must hold tanned leather.
- The output is a copy of the center backpack, NBT included, with 200 added to the damage. A black backpack (1) becomes a big black backpack (201), and the small workbench backpack (17) becomes the big one (217).
- When the output is taken, `onCreated` initializes the save again (section 5.5). The UUID stays, so the contents stay, and the size grows to `backpackSlotsL` (54) or 18 for the workbench.
- It is registered unless `disableBigBackpacks` is true. With `bigByUpgradeOnly` true this is the only way to get a big backpack.

### 4.4 Dyeing, recoloring and undyeing

A colored backpack can be crafted new with the dye in the middle of the leather ring (4.1). That recipe takes any item under the ore dictionary dye name, so modded dyes work.

An existing backpack is recolored with `RecipeRecolorBackpack`, a shapeless recipe that works in any crafting grid, the 2 by 2 player grid included.

- The grid must hold exactly one `ItemBackpack` and exactly one dye item, nothing else. Workbench backpacks are not `ItemBackpack` and cannot be recolored. The ender backpack is refused.
- Accepted dye items are the vanilla `minecraft:dye` in any of its 16 metadata values, vanilla leather and tanned leather. Ore dictionary dyes from other mods are not accepted here.
- A dye sets the color value to `dye metadata + 1` and keeps the tier. A normal backpack stays normal and a big one stays big.
- Leather undyes a normal backpack (tier 0) and is refused for a big one. Tanned leather undyes a big backpack (tier 2) and is refused for a normal one.
- Recoloring to the color the backpack already has is allowed and just consumes the dye.
- The output is a copy of the input backpack with all NBT (UUID, so the contents, and the custom name). Taking it re-initializes the save and updates the `name` tag. The dye or leather is consumed.

### 4.5 Intelligent workbench backpack (`RecipeIntelligentWorkbenchBackpack`)

- Shapeless, any grid. Exactly one workbench backpack (small or big) and exactly one book and quill, nothing else. The code compares with `Items.field_151099_bA`, which is `Items.writable_book`, item id 386 in 1.7.10.
- The output is a copy of the workbench backpack with all NBT plus the item boolean `intelligent` set to true.
- The `ItemCraftedEvent` handler then loads the backpack's save, sets `intelligent` there, saves, and removes the tag from the item (section 12.2). The flag lives in the save file from then on, so it survives the upgrade to the big workbench backpack.
- The book is consumed. An already intelligent backpack is accepted again and nothing changes except that the book is used up.

### 4.6 Config switches that change the recipe set

| Config value | Effect |
|---|---|
| `disableBackpacks` true | Removes the undyed and the 16 colored normal backpack recipes |
| `disableBigBackpacks` true | Removes the undyed and colored big backpack recipes and the upgrade recipe |
| `bigByUpgradeOnly` true | Removes the undyed and colored big backpack recipes, the upgrade stays |
| `disableEnderBackpack` true | Removes the ender backpack recipe |
| `disableWorkbenchBackpack` true | Removes both workbench backpack recipes |
| `airshipModCompatibility` true | Replaces the undyed normal backpack recipe with the chest variant |
| `enderRecipe` 1 | Uses an eye of ender instead of an ender chest |

The bound leather recipe, the smelting recipe, the recolor recipe and the intelligent recipe are always registered.

### 4.7 NBT that survives each recipe

| Recipe | NBT on the output |
|---|---|
| Any shaped recipe of 4.1 | None. The new backpack gets a fresh UUID when it is taken out. |
| Upgrade (4.3) | Everything from the center backpack: `backpack-UID`, `name`, `customName`. Contents, crafting grid and recipe memory stay with the UUID. |
| Recolor and undye (4.4) | Everything from the input backpack. |
| Intelligent (4.5) | Everything from the input workbench backpack plus the transient `intelligent` flag. |
| Bound leather and tanned leather | None. |

Copies made by these recipes keep the UUID, and the input backpack is consumed, so exactly one stack refers to the contents afterwards.

### 4.8 Ingredients and their 1.20.1 equivalents

| 1.7.10 ingredient | How 2.0.1 matches it | 1.20.1 equivalent |
|---|---|---|
| `Items.leather` | Exact item | Tag `forge:leather` (contains only `minecraft:leather` in Forge 47.4.6) |
| `Items.string` | Exact item | Tag `forge:string` (contains only `minecraft:string`) |
| `dyeBlack` and the other 15 dye names | Ore dictionary | Tag `forge:dyes/<color>` (table in 2.2) |
| `Blocks.chest` | Exact item | Tag `forge:chests/wooden` (`minecraft:chest`, `minecraft:trapped_chest` and modded wooden chests), or `minecraft:chest` for an exact copy |
| `Blocks.ender_chest` | Exact item | Tag `forge:chests/ender` (contains only `minecraft:ender_chest`) |
| `Items.ender_eye` | Exact item | `minecraft:ender_eye`, there is no Forge tag |
| `Blocks.crafting_table` | Exact item | `minecraft:crafting_table`, Forge 47.4.6 has no tag for it |
| `Items.writable_book` | Exact item | `minecraft:writable_book`, there is no Forge tag |
| `minecraft:dye` (recolor only) | Vanilla `ItemDye`, any metadata | Any item that Forge's `DyeColor.getColor(stack)` resolves, which checks `DyeItem` and the `forge:dyes/<color>` tags |
| Tanned leather, bound leather | Exact item | `backpack:tanned_leather`, `backpack:bound_leather` |

## 5. Storage

The item only carries a reference. The contents live in one file per backpack in the world save, named after a UUID that is stored on the item.

### 5.1 Item NBT

| Tag | Type | Written by | Meaning |
|---|---|---|---|
| `backpack-UID` | String | Server, at initialization | A random UUID (`UUID.randomUUID()`). It names the save file. Copies of a stack, for example creative clones, share it and therefore share the contents. |
| `name` | String | Server, at every initialization | The unlocalized name plus `.name`, for example `item.backpack.big_red.name`. Used as the default GUI title. |
| `customName` | String | Rename packet | The name typed in the rename screen. Replaces the display name and the GUI title. |
| `intelligent` | Boolean | Intelligent recipe output | Transient. The crafting event handler moves it into the save file and removes it from the item. |

The ender backpack also gets `backpack-UID` and `name`. The item never holds contents, sizes or the intelligent flag for long.

### 5.2 Save files (`SaveFileHandler`)

The handler keeps two folders below the world save root, which it takes from `DimensionManager.getCurrentSaveRootDirectory()`.

- Each backpack has its own file `<world>/backpacks/backpacks/<backpack UUID>.dat`.
- Each player has its own file `<world>/backpacks/player/<player UUID>.dat` (personal slot, out of scope).

Both are gzip compressed NBT files (`CompressedStreamTools.writeCompressed` and `readCompressed`). The handler's `init()` runs on every `WorldEvent.Load`, which means for every dimension and on the client as well, and creates both folders if they are missing.

Writing goes through a temporary file. The handler writes `<name>.dat_new`, deletes `<name>.dat_old`, renames `<name>.dat` to `<name>.dat_old` and renames `<name>.dat_new` to `<name>.dat`. Reading returns an empty compound when `<name>.dat` does not exist. When it exists but cannot be read, the handler logs `[Backpack] Couldn't load data. Using fallback file.` and reads `<name>.dat_old` instead. Files are never deleted. A method `deleteBackpack` exists but is never called, so destroyed backpacks leave their files behind.

All save access is guarded by `BackpackUtil.isServerSide()`, which asks FML for the effective side of the current thread. On the client every `BackpackSave` is an empty compound.

### 5.3 Backpack save file layout

The root compound holds these tags.

| Tag | Type | Content |
|---|---|---|
| `size` | Int | Number of storage slots |
| `slotsPerRow` | Int | Always 9 |
| `type` | Byte | 1 for `Backpack:backpack` (the ender backpack included), 2 for `Backpack:workbenchbackpack`. It selects the GUI factory. |
| `intelligent` | Byte (boolean) | Present on intelligent workbench backpacks |
| `backpackInventories` | Compound | The inventory lists below |

Each list inside `backpackInventories` holds compounds. Every entry is a 1.7.10 `ItemStack.writeToNBT` compound (`id` as a numeric short, `Count` byte, `Damage` short, optional `tag`) with an extra byte `slot`. Only non empty slots are written. On reading, the slot byte is masked with 255 and entries outside the array are ignored.

| List | Used by | Slots |
|---|---|---|
| `backpack` | Every backpack except the ender backpack | 0 to size minus 1 |
| `craftingGrid` | Workbench backpacks | The ghost grid, 0 to 8, row by row |
| `recipes` | Intelligent workbench backpacks | The 9 saved recipe icons |
| `recipe-0` to `recipe-8` | Intelligent workbench backpacks | The ghost ingredients of each saved recipe, slot is the grid index |
| `pickupItems` | Personal slot (out of scope) | The 9 pickup filter stacks |

The UUID itself is not stored inside the file. Because 1.7.10 stores numeric item ids, these files cannot be migrated to 1.20.1, and the port starts with empty storage.

### 5.4 Player save file layout (out of scope)

The root compound has `personalBackpack` (a compound with the worn backpack's `ItemStack`) and `personalBackpackOpen` (a string with the UUID of the worn backpack while it is open through the key, removed on close).

### 5.5 Initialization

The method `BackpackSave.initialize(stack)` does nothing on the client. On the server it runs these steps.

1. It sets `name` on the item.
2. It generates `backpack-UID` if the item has none.
3. It computes the size from the damage. Color 99 (ender) gives 27, tier 2 with a color below 17 gives `backpackSlotsL`, tier 0 with a color below 17 gives `backpackSlotsS`, color 17 on tier 0 gives 9, color 17 on tier 2 gives 18 and everything else gives 0.
4. It sets `slotsPerRow` to 9, `size`, `type`, creates an empty `backpackInventories` if missing and saves the file once. Existing inventory lists are kept.

Initialization runs in three places.

- From `Item.onCreated`, which vanilla calls when a stack is taken from a crafting output slot, the workbench backpack's own output included. It runs with `force`, so an existing UUID is loaded first and then initialized again. This is how an upgraded or recolored backpack gets its new size and `name` while keeping its contents.
- From `onItemRightClick` when the stack has no NBT at all, for example from the creative tab or `/give`.
- From the `BackpackSave(ItemStack)` constructor whenever the server looks at a backpack stack without `backpack-UID`.

### 5.6 When data is read and written

- Opening loads the file and reads the `backpack` list into a new `InventoryBackpack`, a plain array sized by `size`.
- Changes only mark that inventory dirty. Nothing is written while the GUI is open.
- On close the server writes `size` and the `backpack` list if the inventory is dirty. The workbench container also writes `craftingGrid`, `recipes` and `recipe-0` to `recipe-8` and saves the file once.
- Every opening builds a new inventory object from the file. If two players open stacks with the same UUID at the same time, each edits a private copy and the one who closes last overwrites the other (section 13).

## 6. Opening, protection and renaming

### 6.1 Right click

The method `onItemRightClick` runs on both sides.

1. If the stack has no NBT, `onCreated` initializes it on the server.
2. On the client, if the player sneaks and the item is not the ender backpack, the rename screen opens. Nothing else happens on the client.
3. On the server, if the player does not sneak and `openOnlyWornBackpacks` is false, the backpack opens. Sneaking does nothing on the server.

Blocks with their own interaction (chests, crafting tables) take the click first unless the player sneaks. When the player sneaks, the click reaches the item and opens the rename screen.

### 6.2 Opening sequence

The server side is `GuiHelper.displayBackpack`.

1. It closes any open container other than the player inventory and takes the next window id.
2. It builds the inventory. That is the ender chest inventory for the ender backpack, otherwise an `InventoryBackpack` named after the item's `name` and `customName` tags and filled from the save file.
3. It sends `MessageOpenBackpack` with the window id, UUID, type, slots per row, title, a flag whether the title is a custom name, size and the intelligent flag.
4. It builds the container with the factory for the save's `type` (1 normal, 2 workbench), sets it as the open container with the window id and adds the player as a listener, which sends all slot contents.

The client builds a dummy inventory of the received size and title and a `BackpackSave` that holds only UUID, type, slots per row and the intelligent flag. It then opens the matching GUI through the same factory and sets the window id.

### 6.3 Moving, dropping or swapping the open backpack

The server checks the open container every tick through `canInteractWith`.

- The ender backpack's container is always valid.
- Any other backpack's container is valid only while the stack in the selected hotbar slot carries the UUID of the open backpack. For a worn backpack opened by the key, `personalBackpackOpen` is compared instead.

Nothing locks the backpack's own hotbar slot inside the GUI. When the player picks the open backpack up with the cursor, moves it with a number key, throws it with Q or shift clicks it into the main inventory, the next server tick closes the GUI and saves the contents. A backpack held on the cursor at that moment is dropped into the world, because the 1.7.10 `Container.onContainerClosed` drops the cursor stack. No items are lost or duplicated by this, because the contents are stored under the UUID and not in the item. For the ender backpack the GUI simply stays open.

Version 3.0.2 changed this. Its hotbar slot of the held backpack is a `SlotMainHand` whose `canTakeStack` returns false, and its container is always valid.

### 6.4 What may go into a backpack

Every storage slot of a backpack GUI is a `SlotBackpack`. That includes the ender backpack's view of the ender chest. Its `isItemValid` refuses these items.

- Every `ItemBackpackBase`, which means all backpacks including workbench and ender backpacks.
- Items listed in the config string `disallowItems` (section 10).

The container's own `mergeItemStack` checks `isItemValid`, so shift clicking respects the rule. The 1.7.10 number key swap also checks it before it puts a hotbar item into a slot that does not belong to the player. Through a vanilla ender chest block a player can still put backpacks into the ender chest inventory. They then show up in the ender backpack and can be taken out there, but not put back. Shulker boxes did not exist in 1.7.10, so 2.0.1 has no rule for them.

### 6.5 Shift click

The method `transferStackInSlot` moves stacks between regions in this order.

| From | Tries in order |
|---|---|
| Crafting result (workbench) | Backpack storage, hotbar from the right, main inventory |
| Backpack storage | Hotbar from the right, main inventory |
| Main inventory (27 slots) | Backpack storage, hotbar from the right |
| Hotbar | Backpack storage, main inventory |

Ghost slots do not belong to any region and are never moved. The merge first tops up existing stacks of the same item (same damage when the item has subtypes, same NBT) and then fills the first empty slot that accepts the stack.

### 6.6 Renaming

Sneaking and right clicking with any backpack except the ender backpack opens `GuiBackpackRename` (layout in 8.6).

- The text box starts focused and takes at most 32 characters.
- OK stays disabled while the trimmed text is empty, so a name cannot be removed again.
- Enter presses OK and Escape presses Cancel.
- OK sends `MessageRenameBackpack` with the trimmed name and also sets it on the client's copy of the held stack, then closes the screen.
- The server sets `customName` on the held stack if it is a backpack item. It does not check the length.

The custom name becomes the item's display name, without the italics of an anvil name, and the title of the normal and big GUIs. Workbench GUIs show `Crafting` instead of a title, so there the name is only visible on the item.

## 7. Workbench backpack

### 7.1 Parts

- A 3 by 3 ghost crafting grid (`InventoryCraftingGrid` with `SlotPhantom` slots), saved in `craftingGrid`.
- One result slot (`SlotCraftingAdvanced`).
- Storage of 9 or 18 `SlotBackpack` slots, the only source of ingredients.
- A clear button.
- On intelligent backpacks, 9 ghost recipe slots (`InventoryRecipes`) and a save button.

### 7.2 Ghost grid

- A click on a grid slot with the left or right mouse button puts a copy of the cursor stack with a count of 1 into the slot, or clears the slot when the cursor is empty. A middle click always clears it. The cursor stack is never consumed.
- Ghost slots cannot be taken from (`canTakeStack` returns false), and shift click ignores them.
- Any item can be placed as a ghost, backpacks included.
- The grid is saved with the backpack and comes back the next time it is opened.

### 7.3 Result and ingredients

- The result is the vanilla recipe output (`CraftingManager.findMatchingRecipe`) for the ghost grid. It is computed again whenever the grid changes.
- The result can be taken only when the backpack storage holds all ingredients. The ghost stacks are grouped by item and damage and counted. Each group must be covered by storage stacks that are equal (same item and damage, or the same item when it has no subtypes) or share an ore dictionary name with it. The player inventory is never used.
- Taking the result, by click or by shift click, fires the vanilla crafting event and `onCrafting`. It then removes the ingredients from the storage, first from exactly equal stacks in slot order and then from ore dictionary equivalents.
- When a consumed stack has a container item, for example the bucket of a milk bucket, the container item goes into the same slot if that slot became empty, else into the backpack storage, else into the player inventory, else onto the ground. Damageable container items past their maximum damage are destroyed with a `PlayerDestroyItemEvent`. The ore dictionary fallback path does not return container items.
- Shift click on the result puts the crafted stack into the backpack storage first, then into the hotbar from the right, then into the main inventory. Vanilla 1.7.10 repeats the shift click while the result slot still shows the same item, so it crafts until the ingredients run out or there is no room. Only the first region that takes any of the crafted stack is filled, and the rest of that stack is lost (section 13). For shift click the result is computed from the real storage stacks, each ghost slot mapped to a storage slot (exact match first, then ore dictionary), so the crafted item matches the real ingredients.
- The result slot is excluded from double click collecting.

### 7.4 Clear

The button `c` (id 0) or the key c inside the GUI sends `MessageGuiCommand` with command 1. The server empties all nine ghost slots.

### 7.5 Intelligent workbench and recipe memory

An intelligent workbench backpack is made with the recipe in 4.5 and is flagged in its save file. Its GUI moves the grid to the left, puts the result in the middle and shows nine ghost recipe slots on the right (layout in 8.4).

- Save mode starts with the button `s` (id 1) or the key s inside the GUI, which sends `MessageGuiCommand` with command 2. If the result slot holds an item at that moment, the server enters save mode.
- The next click on a recipe slot stores a copy of the current result as that slot's icon and copies of the nine ghost stacks as the recipe's ingredients, then leaves save mode. If the result is empty at that click, nothing is stored and save mode still ends.
- Outside save mode, a click with any mouse button on a recipe slot replaces the whole ghost grid with that recipe's stored ingredients. Positions without a stored ingredient become empty.
- Saved recipes can be overwritten but not removed.
- Both actions run only on the server, and the client sees the result through normal slot updates.
- The button tooltips are `Clear Craft Matrix` for the clear button and the two lines `Save Recipe` and `Click a slot on the right` for the save button.
- The language key `text.backpack.recipes` (Recipes) is the internal name of the recipe inventory and is never drawn.
- The keys c and s work in non intelligent workbench GUIs as well. There save mode has no recipe slots to act on.
- Command values 3 (`PREV`) and 4 (`NEXT`) exist as constants and are never used.

### 7.6 NEI overlay

With NEI present, its recipe transfer button fills the ghost grid. The client clears the grid locally, maps NEI's ingredient positions onto the grid slots (offset x plus 5 and y plus 11 for normal, x minus 17 and y plus 11 for intelligent) and sends `MessageRecipe` with stack and slot index pairs. The server clears the grid and then calls `putStackInSlot` for every pair as received. Section 13 explains why that is unsafe.

## 8. GUI layouts and guiCombined.png

### 8.1 The texture sheet

The texture `assets/backpack/textures/gui/guiCombined.png` is 256 by 256 pixels, RGBA, and is addressed as a 256 by 256 texture. Regions are given as u, v, width, height.

| Region | Content | Used by 2.0.1 |
|---|---|---|
| 0, 0, 176, 167 | A complete window frame in the vanilla style. Its inside also contains a pre drawn row of nine slots at 7, 142 to 168, 159. | Only through the parts below |
| 0, 0, 4, 4 | Top left corner | Yes |
| 4, 0, 100, 4 | Top edge tile (1 px black, 2 px white, then gray, from the outside) | Yes, repeated along x |
| 172, 0, 4, 4 | Top right corner | Yes |
| 0, 4, 4, 100 | Left edge tile, same colors as the top edge | Yes, repeated along y |
| 4, 4, 100, 100 | Background tile, a flat `#C6C6C6` | Yes, repeated |
| 172, 4, 4, 100 | Right edge tile (gray, 2 px `#555555`, 1 px black, from the inside) | Yes, repeated along y |
| 0, 163, 4, 4 | Bottom left corner | Yes |
| 4, 163, 100, 4 | Bottom edge tile, same colors as the right edge | Yes, repeated along x |
| 172, 163, 4, 4 | Bottom right corner | Yes |
| 201, 0, 18, 18 | Slot background: `#373737` top and left, white bottom and right, `#8B8B8B` inside | Yes, for every slot |
| 219, 0, 18, 18 | A darker slot variant | No |
| 201, 18, 26, 26 | A large 26 by 26 slot | No, 2.0.1 stretches the 18 by 18 slot instead and gets the same look |
| 176, 0, 25, 120 | A scroll bar track | No |
| 244, 0, 12, 15 | A scroll bar handle | No |
| 0, 167, 82, 56 | Brewing stand parts | No |
| 0, 223, 27, 15 | Furnace flames | No |
| 0, 238, 22, 15 | Gray crafting arrow | Yes, workbench GUI without intelligence |
| 22, 238, 22, 16 | White progress arrow | No |

A window of width W and height H is drawn from the corners, the edge tiles stretched or repeated over W minus 8 and H minus 8, and the background tile repeated over the inside. Because the edge tiles do not change along their length, the result is the same as drawing the corners, stretching the edges and filling the inside with `#C6C6C6`. Nine slicing the whole 176 by 167 frame would instead show the pre drawn slot row, so the port has to use the parts.

Every slot gets the 18 by 18 slot background at slot x minus 1 and slot y minus 1. The workbench result slot gets a 26 by 26 background at slot x minus 5 and slot y minus 5. In 2.0.1 that is the 18 by 18 slot with its one pixel corners kept and its edges and inside stretched, which looks the same as the ready made region at 201, 18.

Labels are drawn without shadow in `#404040` (4210752) unless noted. Each label text goes through `I18n.format`, so language keys get translated and plain text passes through. Buttons are not drawn from this sheet. They nine slice the vanilla `textures/gui/widgets.png` button rows (v = 46 plus 20 times the state, where state 0 is disabled, 1 normal and 2 hovered) with two pixel borders, so they keep their borders at 11 by 11. Button text is centered at x plus width / 2 plus 1 and y plus (height minus 8) / 2, in `#E0E0E0`, `#A0A0A0` when disabled and `#FFFFA0` when hovered.

### 8.2 Normal, big and ender backpack

All three use `FactoryBackpackNormal` and the same layout code. With S storage slots and R = ceil(S / 9) rows, the numbers are these.

| Element | Position | Notes |
|---|---|---|
| Window | 178 wide, 116 + 18 R high | 178 is two pixels wider than vanilla |
| Title | 8, 6 | Custom name, else the item name, `container.enderchest` for the ender backpack |
| Storage slot i | x = 8 + 18 (i % 9), y = 17 + 18 (i / 9) | Menu slots 0 to S minus 1 |
| Partial last row | First slot at x = 90 minus 9 times its slot count | Centered, only with sizes that are not a multiple of 9 |
| Label `container.inventory` | 8, 19 + 18 R | |
| Main inventory, player slots 9 to 35 | x = 8 + 18 column, y = 31 + 18 R + 18 row | Next 27 menu slots |
| Hotbar, player slots 0 to 8 | x = 8 + 18 column, y = 91 + 18 R | Last 9 menu slots |

Worked values for the default sizes are these.

| Kind | Window | Storage rows y | Inventory label y | Main inventory y | Hotbar y |
|---|---|---|---|---|---|
| Backpack and ender backpack, 27 slots | 178 by 170 | 17, 35, 53 | 73 | 85, 103, 121 | 145 |
| Big backpack, 54 slots | 178 by 224 | 17, 35, 53, 71, 89, 107 | 127 | 139, 157, 175 | 199 |

For comparison, vanilla `ChestMenu` and `ContainerScreen` use a 176 wide window that is 114 + 18 R high, container slots from y 18, the main inventory from y 31 + 18 R (85 for three rows, the same as 2.0.1), the hotbar at 89 + 18 R (2.0.1 has two pixels more gap) and the inventory label at 20 + 18 R.

### 8.3 Workbench backpack without intelligence

| Element | Position | Notes |
|---|---|---|
| Window | 178 wide, 175 + 18 B high | B is 1 storage row (small) or 2 (big), so 193 or 211 |
| Label `container.crafting` | 28, 6 | Left aligned |
| Clear button `c` | 88, 16, size 11 by 11 | Button id 0 |
| Ghost grid slot g (0 to 8) | x = 30 + 18 (g % 3), y = 17 + 18 (g / 3) | Menu slots 1 to 9, same place as the vanilla crafting table |
| Arrow | 90, 35, size 22 by 15 | From 0, 238 |
| Result slot | 125, 35 | Menu slot 0, 26 by 26 background at 120, 30. Vanilla uses 124, 35. |
| Storage slot i | x = 8 + 18 (i % 9), y = 76 + 18 (i / 9) | Menu slots 10 to 9 + storage size |
| Label `container.inventory` | 8, 79 + 18 B | 97 or 115 |
| Main inventory | x = 8 + 18 column, y = 90 + 18 B + 18 row | 108 or 126 for the first row |
| Hotbar | x = 8 + 18 column, y = 150 + 18 B | 168 or 186 |

### 8.4 Workbench backpack with intelligence

| Element | Position | Notes |
|---|---|---|
| Window | Same as 8.3 | |
| Label `container.crafting` | 89, 6 | Centered on the window |
| Clear button `c` | 66, 16, size 11 by 11 | Button id 0 |
| Save button `s` | 81, 16, size 11 by 11 | Button id 1 |
| Ghost grid slot g | x = 8 + 18 (g % 3), y = 17 + 18 (g / 3) | Menu slots 1 to 9 |
| Result slot | 80, 35 | Menu slot 0, 26 by 26 background at 75, 30 |
| Recipe slot r (0 to 8) | x = 116 + 18 (r % 3), y = 17 + 18 (r / 3) | Menu slots 10 to 18 |
| Storage, labels, inventory, hotbar | Same as 8.3 | Storage starts at menu slot 19 |

There is no arrow in this layout. Hovering a button shows its tooltip (7.5).

### 8.5 Menu slot order

| GUI | Menu slot order |
|---|---|
| Normal, big, ender | Storage, main inventory (27), hotbar (9) |
| Workbench | Result, ghost grid (9), storage, main inventory, hotbar |
| Intelligent workbench | Result, ghost grid (9), recipe slots (9), storage, main inventory, hotbar |

### 8.6 Rename screen

The class `GuiBackpackRename` is a plain screen, not a container. It first draws the dark default background and then a 240 by 100 window, centered, with the same frame parts.

| Element | Position | Notes |
|---|---|---|
| Title `text.backpack.rename` | Centered, y 10 | Black (`#000000`) |
| Label `text.backpack.new_name` | 20, 30 | `#404040` |
| Text field | 20, 40, size 200 by 20 | Vanilla text field, focused, 32 characters at most |
| Cancel button (`button.backpack.cancel`) | 40, 70, size 60 by 20 | Button id 1 |
| OK button (`button.backpack.ok`) | 140, 70, size 60 by 20 | Button id 0, enabled only with a non empty trimmed text |

### 8.7 Personal slot GUI (out of scope)

The window is 176 by 159. The personal slot (accepts only backpacks) is at 72, 17. The nine ghost pickup filter slots are at x = 8 + 18 i, y 50. The label `text.backpack.backpack_slot` is at 8, 6 and the label `text.backpack.autopickup` at 8, 38. The main inventory starts at y 74 and the hotbar is at y 134.

## 9. Language files

The jar contains `assets/backpack/lang/en_US.lang` (ASCII) and `assets/backpack/lang/de_DE.lang` (UTF-8). Both have the same 78 keys and CRLF line endings. The blocks below are verbatim copies with the line endings normalized. They are data, so their spelling and punctuation are kept as they are.

### 9.1 English (en_US.lang)

```properties
item.backpack.name=Backpack
item.backpack.medium.name=Middle Backpack
item.backpack.big.name=Big Backpack
item.backpack.black.name=Black Backpack
item.backpack.medium_black.name=Middle Black Backpack
item.backpack.big_black.name=Big Black Backpack
item.backpack.red.name=Red Backpack
item.backpack.medium_red.name=Middle Red Backpack
item.backpack.big_red.name=Big Red Backpack
item.backpack.green.name=Green Backpack
item.backpack.medium_green.name=Middle Green Backpack
item.backpack.big_green.name=Big Green Backpack
item.backpack.brown.name=Brown Backpack
item.backpack.medium_brown.name=Middle Brown Backpack
item.backpack.big_brown.name=Big Brown Backpack
item.backpack.blue.name=Blue Backpack
item.backpack.medium_blue.name=Middle Blue Backpack
item.backpack.big_blue.name=Big Blue Backpack
item.backpack.purple.name=Purple Backpack
item.backpack.medium_purple.name=Middle Purple Backpack
item.backpack.big_purple.name=Big Purple Backpack
item.backpack.cyan.name=Cyan Backpack
item.backpack.medium_cyan.name=Middle Cyan Backpack
item.backpack.big_cyan.name=Big Cyan Backpack
item.backpack.lightGray.name=Light Gray Backpack
item.backpack.medium_lightGray.name=Middle Light Gray Backpack
item.backpack.big_lightGray.name=Big Light Gray Backpack
item.backpack.gray.name=Gray Backpack
item.backpack.medium_gray.name=Middle Gray Backpack
item.backpack.big_gray.name=Big Gray Backpack
item.backpack.pink.name=Pink Backpack
item.backpack.medium_pink.name=Middle Pink Backpack
item.backpack.big_pink.name=Big Pink Backpack
item.backpack.lime.name=Lime Backpack
item.backpack.medium_lime.name=Middle Lime Backpack
item.backpack.big_lime.name=Big Lime Backpack
item.backpack.yellow.name=Yellow Backpack
item.backpack.medium_yellow.name=Middle Yellow Backpack
item.backpack.big_yellow.name=Big Yellow Backpack
item.backpack.lightBlue.name=Light Blue Backpack
item.backpack.medium_lightBlue.name=Middle Light Blue Backpack
item.backpack.big_lightBlue.name=Big Light Blue Backpack
item.backpack.magenta.name=Magenta Backpack
item.backpack.medium_magenta.name=Middle Magenta Backpack
item.backpack.big_magenta.name=Big Magenta Backpack
item.backpack.orange.name=Orange Backpack
item.backpack.medium_orange.name=Middle Orange Backpack
item.backpack.big_orange.name=Big Orange Backpack
item.backpack.white.name=White Backpack
item.backpack.medium_white.name=Middle White Backpack
item.backpack.big_white.name=Big White Backpack
item.backpack.ender.name=Ender Backpack
item.workbenchbackpack.name=Workbench Backpack
item.workbenchbackpack.big.name=Big Workbench Backpack
item.boundLeather.name=Bound Leather
item.tannedLeather.name=Tanned Leather
text.backpack.rename=Rename your backpack
text.backpack.new_name=New name:
text.backpack.backpack_slot=Backpack Slot
text.backpack.update_available=Version %s of the Backpack Mod is now available!
text.backpack.up_to_date=Backpack Mod is up to date
text.backpack.allowed_backpacks=You are not allowed to have more than %s backpacks in your inventory.
text.backpack.dropped_backpacks=%s backpacks were removed from your inventory. Look on the ground.
text.backpack.autopickup=Pickup automatically:
text.backpack.recipes=Recipes
text.backpack.configuration=Backpack configuration
button.backpack.ok=OK
button.backpack.cancel=Cancel
key.personalBackpack=Open Backpack
key.categories.backpack=Backpacks
tooltip.clearCraftMatrix=Clear Craft Matrix
tooltip.saveRecipe=Save Recipe
tooltip.clickASlot=Click a slot on the right
tooltip.slots_used=Slots used
tooltip.tier=Tier:
tooltip.more_information=Press SHIFT for more information
tooltip.intelligent=Intelligent
itemGroup.tab.backpacks=Backpacks
```

### 9.2 German (de_DE.lang)

```properties
item.backpack.name=Rucksack
item.backpack.medium.name=Mittlerer Rucksack
item.backpack.big.name=Großer Rucksack
item.backpack.black.name=Schwarzer Rucksack
item.backpack.medium_black.name=Mittlerer schwarzer Rucksack
item.backpack.big_black.name=Großer schwarzer Rucksack
item.backpack.red.name=Roter Rucksack
item.backpack.medium_red.name=Mittlerer roter Rucksack
item.backpack.big_red.name=Großer roter Rucksack
item.backpack.green.name=Grüner Rucksack
item.backpack.medium_green.name=Mittlerer grüner Rucksack
item.backpack.big_green.name=Großer grüner Rucksack
item.backpack.brown.name=Brauner Rucksack
item.backpack.medium_brown.name=Mittlerer brauner Rucksack
item.backpack.big_brown.name=Großer brauner Rucksack
item.backpack.blue.name=Blauer Rucksack
item.backpack.medium_blue.name=Mittlerer blauer Rucksack
item.backpack.big_blue.name=Großer blauer Rucksack
item.backpack.purple.name=Lila Rucksack
item.backpack.medium_purple.name=Mittlerer lila Rucksack
item.backpack.big_purple.name=Großer lila Rucksack
item.backpack.cyan.name=Cyan Rucksack
item.backpack.medium_cyan.name=Mittlerer cyan Rucksack
item.backpack.big_cyan.name=Großer cyan Rucksack
item.backpack.lightGray.name=Hell grauer Rucksack
item.backpack.medium_lightGray.name=Mittlerer hell grauer Rucksack
item.backpack.big_lightGray.name=Großer hell grauer Rucksack
item.backpack.gray.name=Grauer Rucksack
item.backpack.medium_gray.name=Mittlerer grauer Rucksack
item.backpack.big_gray.name=Großer grauer Rucksack
item.backpack.pink.name=Pinker Rucksack
item.backpack.medium_pink.name=Mittlerer pinker Rucksack
item.backpack.big_pink.name=Großer pinker Rucksack
item.backpack.lime.name=Hell grüner Rucksack
item.backpack.medium_lime.name=Mittlerer hell grüner Rucksack
item.backpack.big_lime.name=Großer hell grüner Rucksack
item.backpack.yellow.name=Gelber Rucksack
item.backpack.medium_yellow.name=Mittlerer gelber Rucksack
item.backpack.big_yellow.name=Großer gelber Rucksack
item.backpack.lightBlue.name=Hell blauer Rucksack
item.backpack.medium_lightBlue.name=Mittlerer hell blauer Rucksack
item.backpack.big_lightBlue.name=Großer hell blauer Rucksack
item.backpack.magenta.name=Magenta Rucksack
item.backpack.medium_magenta.name=Mittlerer magenta Rucksack
item.backpack.big_magenta.name=Großer magenta Rucksack
item.backpack.orange.name=Oranger Rucksack
item.backpack.medium_orange.name=Mittlerer oranger Rucksack
item.backpack.big_orange.name=Großer oranger Rucksack
item.backpack.white.name=Weißer Rucksack
item.backpack.medium_white.name=Mittlerer weißer Rucksack
item.backpack.big_white.name=Großer weißer Rucksack
item.backpack.ender.name=Ender Rucksack
item.workbenchbackpack.name=Werkbank Rucksack
item.workbenchbackpack.big.name=Großer Werkbank Rucksack
item.boundLeather.name=Gebundenes Leder
item.tannedLeather.name=Gegerbtes Leder
text.backpack.rename=Benenne deinen Rucksack um
text.backpack.new_name=Neuer name:
text.backpack.backpack_slot=Rucksack Slot
text.backpack.update_available=Version %s der Backpack Mod ist jetzt verfügbar!
text.backpack.up_to_date=Backpack Mod ist aktuell
text.backpack.allowed_backpacks=Du darfst nicht mehr als %s Rucksäcke im Inventar haben.
text.backpack.dropped_backpacks=%s Rucksäcke wurden aus deinem Inventar entfernt. Guck auf den Boden.
text.backpack.autopickup=Nimm automatisch auf:
text.backpack.recipes=Rezepte
text.backpack.configuration=Backpack Konfiguration
button.backpack.ok=OK
button.backpack.cancel=Abbrechen
key.personalBackpack=Rucksack öffnen
key.categories.backpack=Rucksäcke
tooltip.clearCraftMatrix=Craft Matrix leeren
tooltip.saveRecipe=Rezept speichern
tooltip.clickASlot=Klicke auf einen Slot rechts
tooltip.slots_used=Slots benutzt
tooltip.tier=Tier:
tooltip.more_information=Drücke SHIFT für mehr Informationen
tooltip.intelligent=Intelligent
itemGroup.tab.backpacks=Rucksäcke
```

### 9.3 Where the keys are used

| Keys | Used for | In the port |
|---|---|---|
| `item.backpack.*`, `item.workbenchbackpack.*`, `item.boundLeather.name`, `item.tannedLeather.name` | Item names, default GUI titles | Yes, without the `medium` keys |
| `item.backpack.medium*` | Dead medium tier | No |
| `itemGroup.tab.backpacks` | Creative tab title | Yes |
| `tooltip.more_information`, `tooltip.tier`, `tooltip.slots_used`, `tooltip.intelligent` | Item tooltip | Yes |
| `tooltip.clearCraftMatrix`, `tooltip.saveRecipe`, `tooltip.clickASlot` | Workbench button tooltips | Yes |
| `text.backpack.rename`, `text.backpack.new_name`, `button.backpack.ok`, `button.backpack.cancel` | Rename screen | Yes |
| `text.backpack.recipes` | Internal name of the recipe inventory, never drawn | Optional |
| `text.backpack.backpack_slot`, `text.backpack.autopickup`, `key.personalBackpack`, `key.categories.backpack` | Personal slot and key binding | No (out of scope) |
| `text.backpack.allowed_backpacks`, `text.backpack.dropped_backpacks` | `maxBackpackAmount` chat messages | No |
| `text.backpack.update_available`, `text.backpack.up_to_date` | Version check | No |
| `text.backpack.configuration` | In game config screen title | No |

The GUIs also use the vanilla keys `container.inventory`, `container.crafting` and `container.enderchest`, which still exist in 1.20.1.

## 10. Configuration

The file is `config/Backpack.cfg`, a Forge `Configuration` with everything in the category `general`. The mod's config factory also offers an in game config screen.

| Key | Type | Default | Accepted | Effect |
|---|---|---|---|---|
| `enderRecipe` | Int | 0 | 0 or 1, else 0 | 0 crafts the ender backpack with an ender chest, 1 with an eye of ender |
| `backpackSlotsS` | Int | 27 | 1 to 128, else 27 | Slots of the normal backpack |
| `backpackSlotsL` | Int | 54 | 1 to 128, else 54 | Slots of the big backpack |
| `maxBackpackAmount` | Int | 0 | 0 to 36, else 0 | Most backpacks a player may carry, 0 means unlimited (11.4) |
| `renderBackpackModel` | Boolean | `true` | | Draws the model of the worn backpack (11.3) |
| `openOnlyWornBackpacks` | Boolean | `false` | | Right click no longer opens backpacks, only the key opens the worn one |
| `airshipModCompatibility` | Boolean | `false` | | The undyed normal backpack needs a chest in the middle |
| `disableBackpacks` | Boolean | `false` | | Normal backpacks are not craftable |
| `disableBigBackpacks` | Boolean | `false` | | Big backpacks are not craftable, upgrade included |
| `disableEnderBackpack` | Boolean | `false` | | The ender backpack is not craftable |
| `disableWorkbenchBackpack` | Boolean | `false` | | Workbench backpacks are not craftable |
| `bigByUpgradeOnly` | Boolean | `false` | | Big backpacks come only from the upgrade recipe |
| `disallowItems` | String | Empty string | | Comma separated list of items that may not go into a backpack |

Entries of `disallowItems` are split at `:`. The first part is looked up in the item registry, which adds `minecraft:` to a bare name. An optional second part is a metadata number, and without it every metadata is refused. The code then means to treat a first part that is not an item as an ore dictionary name, but it passes the failed registry result (null) to `OreDictionary.getOreID` instead of the name, so ore dictionary entries never match. In practice only bare vanilla names work, such as `planks` for all planks or `planks:2` for birch planks. Item ids of other mods cannot be written because of the split, and numeric ids are not resolved, so none of the three entries of the example in the config comment (`1,5:2,ingotSilver`) has any effect.

The comments the mod writes into the file follow, line by line. The key names are added here as headings, and the `##############` lines that frame each comment are left out. The text is data and keeps its original wording.

```text
enderRecipe
    Recipe to craft ender backpack
    0 ender chest
    1 eye of the ender
backpackSlotsS and backpackSlotsL
    Number of slots a backpack has
    valid: integers 1-128
maxBackpackAmount
    Number of backpacks a player can have in his inventory
    valid: integers 0-36
    0 = unlimited
renderBackpackModel
    If true the backpack 3D model will be rendered.
openOnlyWornBackpacks
    If true you can only open a backpack that you wear in the extra slot
airshipModCompatibility
    If true normal backpack requires a chest in the middle
disableBackpacks
    If true small backpacks are not craftable
disableBigBackpacks
    If true big backpacks are not craftable
disableEnderBackpack
    If true ender backpacks are not craftable
disableWorkbenchBackpack
    If true workbench backpacks are not craftable
bigByUpgradeOnly
    If true big backpacks can only crafted by upgrading a small one
disallowItems
    Example:
    disallowItems:1,5:2,ingotSilver

    This will disallow stone, birch wood planks and any type of silver ingots in backpacks.
```

## 11. Out of scope features

These features are not part of the first port. They are described so that they can be added later.

### 11.1 Personal slot and the key binding

- Each player has one hidden personal backpack slot, stored in the player save file (5.4), not in the player inventory.
- The key binding `key.personalBackpack` in the category `key.categories.backpack` defaults to B (LWJGL key code 48).
- Pressing it in game sends `MessageOpenGui` with 0, and the server opens the worn backpack and records its UUID in `personalBackpackOpen`.
- Pressing it while sneaking sends 1, and the server opens the personal slot GUI (8.7), where a backpack can be put on or taken off.
- Pressing the key inside a backpack GUI closes the GUI.
- On death the worn backpack is added to the drops and the slot is cleared (`PlayerDropsEvent`).
- With `openOnlyWornBackpacks` true, only the worn backpack can be opened.
- In 1.20.1 the natural home for this would be a Curios slot, and Curios is in the modpack.

### 11.2 Automatic pickup (`InventoryPickup`)

The class `InventoryPickup` is a ghost inventory of 9 slots with a stack limit of 1, shown in the personal slot GUI below the worn backpack and saved in that backpack's `pickupItems` list. It can only be edited while a backpack is worn.

When the player picks up an item entity (`EntityItemPickupEvent`), the server checks the worn backpack's nine filter stacks. For every filter stack equal to the picked up stack, including ore dictionary equivalents, it merges the item entity's stack into the worn backpack's storage, which shrinks the entity's stack in place. Vanilla then picks up whatever is left. If anything went into the backpack, the backpack is saved by calling the pickup container's `onContainerClosed`, which in 1.7.10 also drops whatever the player holds on the cursor.

### 11.3 Backpack model on the player

With `renderBackpackModel` true, the client handles `RenderPlayerEvent.Specials.Pre`. For every rendered player and every frame it sends `MessagePersonalBackpack` with the player's UUID to the server and stores the answer, the damage of the worn backpack or -1. When the stored value is not -1, it draws `ModelBackpack` (a `ModelBiped` subclass with a bag, pockets, ledges and strings, 64 by 32 texture layout) with `textures/model/backpack.png`. That texture is 256 by 128, four times the layout, and is the same for every color. The bag tilts by 0.5 radians around x while the player sneaks.

### 11.4 Maximum backpack amount

With `maxBackpackAmount` above 0, the server counts on every player tick the backpacks in the 36 main inventory slots plus the worn one. Every backpack beyond the limit is dropped at the player's position and removed from its slot. The player then gets two chat lines, each prefixed with `[Backpacks] `, built from `text.backpack.allowed_backpacks` and `text.backpack.dropped_backpacks`.

### 11.5 Other

- A fingerprint check whose placeholder makes it always pass.
- The VersionChecker IMC message with an update URL.
- The in game config screen (`GuiConfiguration`, title `text.backpack.configuration`).
- The NEI overlay handler (7.6).
- The Inventory Tweaks annotations, which mark the backpack containers as chests and name their sections (crafting output and grid, inventory, hotbar, chest).

## 12. Lifecycle, event handlers and network messages

### 12.1 Lifecycle

| Phase | Work |
|---|---|
| Pre init | Load the config, create and register the four items, register the key binding (client), send the VersionChecker IMC |
| Init | Register recipes and the recipe sorter entries, register the network messages, register event handlers |
| Post init | Try to register the NEI overlay handler |

The recipe sorter registers the upgrade as shaped (`backpack:enhanceBackpack`) and the intelligent and recolor recipes as shapeless (`backpack:intelligentWorkbench`, `backpack:recolorBackpack`).

### 12.2 Event handlers

| Event | Side | Effect | Port |
|---|---|---|---|
| `PlayerEvent.ItemCraftedEvent` | Both, effective on the server | When the crafted stack is a workbench backpack with the item tag `intelligent`, it sets `intelligent` in the save file and removes the item tag | Replaced by the item flag (14) |
| `WorldEvent.Load` | Both | `SaveFileHandler.init()`, creates the save folders | Replaced by world data |
| `TickEvent.PlayerTickEvent` | Server | Backpack limit (11.4) | No |
| `EntityItemPickupEvent` | Server | Automatic pickup (11.2) | No |
| `PlayerDropsEvent` | Server | Drops the worn backpack (11.1) | No |
| `RenderPlayerEvent.Specials.Pre` | Client | Backpack model (11.3) | No |
| `ConfigChangedEvent.OnConfigChangedEvent` | Client | Reloads the config after the config screen | No |
| `InputEvent.KeyInputEvent` | Client | Key binding (11.1) | No |

### 12.3 Network messages

All messages use the FML `SimpleNetworkWrapper` channel `Backpack`.

| Id | Message | Direction | Payload | Purpose |
|---|---|---|---|---|
| 0 | `MessageRenameBackpack` | To the server | UTF-8 name | Sets `customName` on the held backpack |
| 1 | `MessageOpenGui` | To the server | Byte, 0 worn backpack, 1 personal slot GUI | Key binding (out of scope) |
| 2 | `MessageGuiCommand` | To the server | Byte, 1 clear, 2 save | Workbench buttons and keys |
| 3 | `MessagePersonalBackpack` | To the server | Player UUID string, int | Model request (out of scope) |
| 4 | `MessageRecipe` | To the server | Count, then pairs of item stack and slot index | NEI recipe transfer |
| 10 | `MessageOpenPersonalSlot` | To the client | Window id | Opens the personal slot GUI (out of scope) |
| 11 | `MessageOpenBackpack` | To the client | Window id int, UUID string, type byte, slots per row int, name string, custom name flag, size int, intelligent flag | Opens a backpack GUI |
| 12 | `MessagePersonalBackpack` | To the client | Player UUID string, worn backpack damage int (-1 for none) | Model answer (out of scope) |

## 13. Known defects in 2.0.1

The port should not copy these.

1. The tooltip slot line always reads `0/0 Slots used`, and the `Intelligent` line never appears. The tooltip runs on the client thread, where `BackpackSave` never loads anything. Version 3.0.2 fixed this by writing `slots` and `slots_used` into the item NBT.
2. Two players who open stacks with the same UUID each edit a private copy, and the last one to close overwrites the other. That duplicates or deletes items. Same UUID stacks come from creative cloning.
3. The message `MessageRecipe` trusts the client. The server calls `putStackInSlot` with any slot index and any item stack it receives, so while a workbench backpack is open, a modified client can create items in any slot of that container, the player inventory included.
4. The check `canInteractWith` reads the player save file from disk every tick while a backpack is open. With `maxBackpackAmount` set, the player tick does the same for every player. The model renderer sends one packet per rendered player per frame.
5. The event `WorldEvent.Load` also fires on a client that joins a server, where the save root is null. The client then creates `backpacks/backpacks` and `backpacks/player` relative to the game directory.
6. The medium tier shows up in the creative tab with missing textures and no slots.
7. Moving the open backpack drops it on the ground (6.3).
8. The config value `disallowItems` only works for bare vanilla item names. Ore dictionary entries never match, and ids of other mods or numeric ids cannot be written (10).
9. The automatic pickup drops the cursor stack (11.2).
10. GUI labels pass custom names through `I18n.format`, so a custom name that equals a language key is shown translated, and a name with a `%` sign may show a format error.
11. Save files of destroyed backpacks are never removed (5.2).
12. The custom recipe classes keep the last match in a field of a shared instance, which the client and the integrated server touch from different threads in single player.
13. Shift clicking the workbench result fills only the first region that takes any of the crafted stack. Whatever does not fit there is lost, because the merged stack is a fresh copy and not the content of a slot.
14. Shift click crafting puts a copy of the output into the inventory before `onCreated` runs on the original stack. A new backpack made that way is only initialized on first use. An upgraded or recolored one keeps its old `name` tag, so its GUI title still shows the old size or color.

## 14. Port notes

These are recommendations for the 1.20.1 design where the 1.7.10 concepts do not exist anymore.

### 14.1 Items, ids and assets

- Register 39 items with the ids from 2.3 and no metadata. One `BackpackItem` class with a kind (normal, big, workbench, big workbench, ender) and an optional `DyeColor` covers all 37 backpacks, and the two leathers are plain items. Backpacks stack to 1.
- Item tags make the rules data driven: `backpack:backpacks` (all 37), `backpack:small_backpacks` and `backpack:big_backpacks` (17 each, undyed included) and `backpack:not_allowed_in_backpacks`, which contains `#backpack:backpacks` by default and replaces `disallowItems`.
- Copy the 39 item textures to `assets/backpack/textures/item/<id path>.png`, give each item a `minecraft:item/generated` model, and copy `guiCombined.png` to `assets/backpack/textures/gui/gui_combined.png`. The model texture is not needed yet.
- Language files become `en_us.json` and `de_de.json` with keys like `item.backpack.black_backpack`. Keep the original wording of 9.1 and 9.2, minus the out of scope keys.
- One creative tab `backpack:backpacks` titled Backpacks (Rucksäcke) in the 2.0.1 order: undyed and the 16 colors in the order of 2.2, the big ones in the same order, the ender backpack, the workbench and the big workbench backpack. The leathers go into the vanilla Ingredients tab through `BuildCreativeModeTabContentsEvent`, like the Materials tab of 2.0.1.
- Drop the medium tier, the version check, the fingerprint check, NEI and Inventory Tweaks support, the in game config screen and the four out of scope features.

### 14.2 Recipes

- Ship plain data recipes with the tags from 4.8. A typical one is `minecraft:crafting_shaped` with the pattern `LLL`, `LDL`, `LLL`, the key L as `{"tag": "forge:leather"}`, D as `{"tag": "forge:dyes/black"}` and the result `{"item": "backpack:black_backpack"}`.
- Smelting becomes `minecraft:smelting` from `backpack:bound_leather` to `backpack:tanned_leather` with 0.1 experience and 200 ticks.
- Upgrade, recolor and intelligent need the output to keep the input backpack's NBT. Two small serializers, a `ShapedRecipe` subclass and a `ShapelessRecipe` subclass that copy the tag of the first backpack ingredient onto the result, keep these recipes visible in EMI and JEI. A `CustomRecipe` would hide them.
- The upgrade is then 18 shaped recipes (each normal backpack and the small workbench backpack, tanned leather around it).
- The recolor is 32 shapeless recipes (`#backpack:small_backpacks` or `#backpack:big_backpacks` plus `forge:dyes/<color>`) plus two undye recipes (small plus leather, big plus tanned leather).
- The intelligent upgrade is two shapeless recipes, a workbench backpack plus `minecraft:writable_book`, with the flag in the result NBT. Forge 47.4.6 reads `nbt` in crafting results through `CraftingHelper.getItemStack`.
- Leave out the config switches of 4.6. KubeJS in the pack can remove or change recipes, and the ender chest variant is the default worth keeping.

### 14.3 Storage

- Keep the 2.0.1 model of a UUID on the item and the contents in the world. Put each backpack into its own `SavedData` in the overworld's `DimensionDataStorage`, for example named `backpack_<uuid>`. That keeps one file per backpack as 2.0.1 did, now under `<world>/data/`, and vanilla writes it with the world.
- The entry holds the storage in the vanilla `ContainerHelper` format (an `Items` list with `Slot` bytes), the ghost grid, the nine recipe icons and their ingredients.
- Keep exactly one live container object per UUID on the server and let every menu use it. Mark the data dirty on every change. This removes defect 2 of section 13 and the dependence on closing the GUI.
- Item NBT then only needs the UUID (for example `BackpackId` through `putUUID`), the intelligent flag on workbench backpacks and, for the tooltip, a used slot count that the server writes when a menu closes. Assign the UUID on the server the first time a backpack is opened. Recipes that copy NBT carry it along. Do not rely on `onCraftedBy` alone, since shift click crafting can move a copy that never sees it (defect 14).
- The ender backpack needs no data. It opens `player.getEnderChestInventory()`, a `PlayerEnderChestContainer` of 27 slots, titled `container.enderchest`.
- Do not delete data when an item entity is destroyed, because copies may still exist. That matches 2.0.1.

### 14.4 Menus and screens

- Register menu types with `IForgeMenuType.create` and open them with `NetworkHooks.openScreen`. The extra data carries the kind, the storage size, the intelligent flag and the hand that was used. The server menu wraps the live container, and the client menu a `SimpleContainer` of the same size.
- Use the slot coordinates, slot order and window sizes of section 8 and draw the window as described in 8.1, from `gui_combined.png` with labels in `#404040`. Vanilla `ChestMenu` cannot be reused for the normal backpacks, because its slots would accept backpacks.
- Storage slots refuse `#backpack:not_allowed_in_backpacks`. Use the same menu for the ender backpack so that it keeps that rule. Leave `Item.canFitInsideContainerItems` at the vanilla default, because 2.0.1 had no rule for shulker boxes and the contents are stored by reference anyway.
- The method `stillValid` should check that the stack in the remembered hand still carries the UUID, as 2.0.1 did.
- Lock the open backpack as 3.0.2 did. Its hotbar slot gets `mayPickup` false, and `clicked` refuses `ClickType.SWAP` with the selected hotbar index as button (or 40 when the backpack is in the off hand). This replaces the close and drop behavior of 6.3.
- The method `quickMoveStack` follows the order of 6.5.
- In 1.20.1 `Player.remove` closes an open menu on logout, and `AbstractContainerMenu.removed` puts the cursor stack back into the inventory.

### 14.5 Workbench backpack

- Handle the ghost grid and the recipe slots in `clicked` as in 7.2 and 7.5.
- Keep the grid in a `TransientCraftingContainer` of 3 by 3 and find the recipe with `RecipeManager.getRecipeFor(RecipeType.CRAFTING, grid, level)`.
- The result slot's `mayPickup` checks the storage, and its `onTake` removes the ingredients from the storage only.
- Replace the ore dictionary fallback by asking the recipe. A storage stack can stand in for a ghost stack when it is the same item with the same tags, or when the recipe still matches with that stack in the ghost's place.
- Put the remainders from `recipe.getRemainingItems` back as in 7.3, fire `ForgeEventFactory.firePlayerCraftingEvent` and call `onCraftedBy` on the result.
- Shift click on the result repeats until the ingredients or the space run out, storage first.
- The clear and save buttons can use the vanilla `clickMenuButton` path (`ServerboundContainerButtonClickPacket`), so they need no custom packet. The c and s hotkeys are optional.
- Recipe transfer from EMI or JEI is optional. If it is added, the server must only set ghost copies with a count of 1 into the nine grid slots (defect 3).

### 14.6 Rename, tooltip and client separation

- Rename keeps the sneak and right click trigger and the 32 character limit, plus one serverbound packet on a `SimpleChannel`. The server checks that the hand holds a backpack that is not the ender backpack and that the trimmed name has 1 to 32 characters. It then sets the vanilla custom name with `setHoverName(Component.literal(name))`, which also becomes the GUI title and keeps anvil names consistent.
- Build the tooltip from item data only, with `Screen.hasShiftDown()`. Show the tier line as 1 for normal and 3 for big, as in 2.0.1, the used slot line from the item NBT and `Intelligent` from the item flag.
- Keep every `Screen`, `MenuScreens.register` call and other client code in a client package that only `Dist.CLIENT` event subscribers reach. The method `Item.use` should open the rename screen through `DistExecutor` or an equivalent client only indirection, so that a dedicated server never loads screen classes.
- No mixins are needed.

### 14.7 Modpack compatibility

- Arclight runs vanilla menus and `SavedData` normally. The port should not depend on anything Bukkit specific.
- EMI and JEI show the data recipes, including the NBT copying subclasses from 14.2.
- Inventory Sorter 23.0.11 (in the pack) accepts the IMC messages `slotblacklist` (slot class names) and `containerblacklist` (menu type ids) and has the same lists in its server config. The ghost grid, recipe and result slot classes should be on the slot blacklist.
- Quark 4.0 provides `org.violetmoon.quark.api.IQuarkButtonAllowed` and `ISortingLockedSlots` for an optional integration.
- Sophisticated Backpacks is also in the pack. Its undyed backpack is also called Backpack, which only matters for searches.
- No mod in the pack uses the mod id `backpack`. The `META-INF/mods.toml` files of all 235 jars in the server repository were checked.
