package com.skytekx.backpack.menu.slot;

import net.minecraft.world.Container;

/** A saved recipe of an intelligent workbench backpack. It shows the icon and holds no real item. */
public class RecipeSlot extends DisplaySlot {
    public RecipeSlot(EmptyContainer placeholder, Container icons, int index, int x, int y) {
        super(placeholder, icons, index, x, y);
    }
}
