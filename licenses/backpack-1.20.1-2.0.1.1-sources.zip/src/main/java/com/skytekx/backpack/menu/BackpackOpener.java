package com.skytekx.backpack.menu;

import com.skytekx.backpack.item.BackpackItem;
import com.skytekx.backpack.item.BackpackKind;
import com.skytekx.backpack.storage.BackpackData;
import com.skytekx.backpack.storage.BackpackStorage;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkHooks;

/** Opens the backpack a player holds, on the server. */
public final class BackpackOpener {
    private BackpackOpener() {
    }

    public static void open(ServerPlayer player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(stack.getItem() instanceof BackpackItem item)) {
            return;
        }
        BackpackKind kind = item.kind();
        int lockedSlot = hand == InteractionHand.MAIN_HAND ? player.getInventory().selected : AbstractBackpackMenu.OFFHAND_SLOT;
        if (kind.isEnder()) {
            MenuInfo info = new MenuInfo(kind, lockedSlot, false);
            MenuProvider provider = new SimpleMenuProvider((containerId, inventory, p) -> new BackpackMenu(containerId, inventory,
                    player.getEnderChestInventory(), kind, lockedSlot, null, null), Component.translatable("container.enderchest"));
            NetworkHooks.openScreen(player, provider, info::write);
            return;
        }
        UUID id = BackpackItem.getOrCreateId(stack);
        BackpackData data = BackpackStorage.get(player.server, id);
        data.storage().ensureSize(kind.storageSize());
        BackpackItem.setUsedSlots(stack, data.storage().countUsed(kind.storageSize()));
        boolean intelligent = kind.isWorkbench() && BackpackItem.isIntelligent(stack);
        MenuInfo info = new MenuInfo(kind, lockedSlot, intelligent);
        MenuProvider provider = new SimpleMenuProvider((containerId, inventory, p) -> kind.isWorkbench()
                ? new WorkbenchBackpackMenu(containerId, inventory, kind, lockedSlot, intelligent, id, data)
                : new BackpackMenu(containerId, inventory, data.storage(), kind, lockedSlot, id, data::setDirty),
                stack.getHoverName());
        NetworkHooks.openScreen(player, provider, info::write);
    }
}
