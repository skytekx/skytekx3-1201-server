package com.skytekx.backpack.item;

/**
 * The kinds of backpack that 2.0.1 offered. The medium tier of 2.0.1 never worked and is left out.
 */
public enum BackpackKind {
    /** The undyed backpack and its 16 colors, 2.0.1 damage 0 to 16. */
    NORMAL(27, 1, false),
    /** The big backpack and its 16 colors, 2.0.1 damage 200 to 216. */
    BIG(54, 3, false),
    /** The workbench backpack, 2.0.1 damage 17. */
    WORKBENCH(9, 1, true),
    /** The big workbench backpack, 2.0.1 damage 217. */
    BIG_WORKBENCH(18, 3, true),
    /** The ender backpack, 2.0.1 damage 31999. It shows the player's ender chest. */
    ENDER(27, 0, false);

    private final int storageSize;
    private final int tier;
    private final boolean workbench;

    BackpackKind(int storageSize, int tier, boolean workbench) {
        this.storageSize = storageSize;
        this.tier = tier;
        this.workbench = workbench;
    }

    /** The number of storage slots, without the crafting grid of the workbench backpacks. */
    public int storageSize() {
        return storageSize;
    }

    /** The number of storage rows of nine slots. */
    public int storageRows() {
        return storageSize / 9;
    }

    /** The tier the 2.0.1 tooltip shows. It skips 2 because of the dead medium tier. */
    public int tier() {
        return tier;
    }

    public boolean isWorkbench() {
        return workbench;
    }

    public boolean isEnder() {
        return this == ENDER;
    }

    public static BackpackKind byOrdinal(int ordinal) {
        BackpackKind[] values = values();
        return ordinal >= 0 && ordinal < values.length ? values[ordinal] : NORMAL;
    }
}
